﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using System.Net;
using System.IO;
using ExcelDataReader;
using System.Data;
using System.Configuration;
using System.Data.OleDb;
using System.Data.SqlClient;
using PagedList;
using SMSTool.Models;


namespace SMSTool.Controllers
{
    public class SendSMSController : Controller
    {
        SMSToolEntities db = new SMSToolEntities();
        // GET: SendSMS
        public ActionResult Index()
        {

            ProcessSMS _model = new ProcessSMS();
            var SenderList = db.SMSConfigurations.ToList().Where(a => a.IsActive.Equals(true));

            _model.SenderList = (from d in SenderList
                                     select new SelectListItem
                                          {
                                              Value = d.Id.ToString(),
                                              Text = d.Sender
                                          }).ToList();

          

            var qq = (from p in db.SMSConfigurations
                      join e in db.MessageConfigurations on p.Id equals e.SMSConfigurationId
                      select new ProcessSMS
                      {
                          Id = e.Id,
                          Messages = e.Message,
                          Sender = p.Sender
                      }).ToList();

            _model.MessageConfig = qq;

            return View("Index",_model);
        }

        public ActionResult Filter(int SenderId)
        {
            int? Send_ID = Convert.ToInt32(SenderId);
            List<ProcessSMS> y = null;
            var qq = y;
            if (Send_ID == 0)
            {
                qq = (
                      from p in db.SMSConfigurations
                      join e in db.MessageConfigurations on p.Id equals e.SMSConfigurationId

                      select new ProcessSMS
                      {
                          Id = e.Id,
                          Messages = e.Message,
                          Sender = p.Sender
                      }).ToList();
            }
            else
            {
                qq = (from p in db.SMSConfigurations
                      join e in db.MessageConfigurations on p.Id equals e.SMSConfigurationId
                      where e.SMSConfigurationId== Send_ID
                      select new ProcessSMS
                      {
                          Id = e.Id,
                          Messages = e.Message,
                          Sender = p.Sender
                      }).ToList();
            
            }
          
            return PartialView("_Messagelist", qq);
        }
        public ActionResult SendSMSProcess()
        {
            return View();
        }

        

    }
}