﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using System.Net;
using System.IO;
using ExcelDataReader;
using System.Data;
using System.Configuration;
using System.Data.OleDb;
using System.Data.SqlClient;
using PagedList;
using SMSTool.Models;


namespace SMSTool.Controllers
{
    public class MessageConfigurationController : Controller
    {
        SMSToolEntities db = new SMSToolEntities();

        // GET: MessageConfiguration
        public ActionResult Index()
        {
            var viewModel =
            from pd in db.SMSConfigurations
            join p in db.MessageConfigurations on pd.Id equals p.SMSConfigurationId
            where pd.IsActive == true
            select new ViewModel { SMSConfig = pd, MessageConfig = p };
            return View(viewModel.AsEnumerable());
            
        }

        public void bindSenderList()
        {
            List<SMSConfiguration> SenderList = new List<SMSConfiguration>();
            SenderList = (from s in db.SMSConfigurations
                          select s).ToList();
            ViewBag.SenderList = SenderList;
        }

        public ActionResult Save()
        {
            bindSenderList();
            ViewBag.ButtonText = "Submit";
            return View();
        }

        [HttpPost]
        public ActionResult Save(MessageConfiguration MessageDetails)
        {
            if (ModelState.IsValid)
            {
                if (Session["Id"] != null)
                {
                    MessageDetails.Id = Convert.ToInt32(Session["Id"]);
                    using (SMSToolEntities db = new SMSToolEntities())
                    {
                        MessageConfiguration updatedDetails = (from c in db.MessageConfigurations
                                                               where c.Id == MessageDetails.Id
                                                           select c).FirstOrDefault();

                        updatedDetails.SMSConfigurationId = MessageDetails.SMSConfigurationId;
                        updatedDetails.Message = MessageDetails.Message;
                        updatedDetails.UpdatedDate = MessageDetails.UpdatedDate;
                        db.SaveChanges();
                    }

                }
                else
                {
                    MessageDetails.SMSConfigurationId = 1;
                    MessageDetails.CreatedDate = DateTime.Now;
                    db.MessageConfigurations.Add(MessageDetails);
                    db.SaveChanges();
                }

                ModelState.Clear();
                MessageDetails.Id = 0;
                Session["Id"] = null;
            }
            bindSenderList();
            return RedirectToAction("Index");
        }

        public ActionResult Cancel(MessageConfiguration MessageDetails)
        {
            MessageDetails.Id = 0;
            Session["Id"] = null;
            return View("Index");
        }

        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ViewBag.Operation = id;
            ViewBag.Name = db.MessageConfigurations.ToList();

            MessageConfiguration MessageDetails = db.MessageConfigurations.Find(id);

            Session["Id"] = id;
            ViewBag.ButtonText = "Update";
            bindSenderList();
            return View("Save", MessageDetails);
        }

        public ActionResult Delete(int id)
        {
            MessageConfiguration objMessage = db.MessageConfigurations.Find(id);
            db.MessageConfigurations.Remove(objMessage);
            db.SaveChanges();
            return RedirectToAction("Index", new { id = 0 });
        }
    }
}