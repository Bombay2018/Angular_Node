﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using System.Net;
using System.IO;
using ExcelDataReader;
using System.Data;
using System.Configuration;
using System.Data.OleDb;
using System.Data.SqlClient;
using PagedList;

namespace SMSTool.Controllers
{
    public class SMSConfigurationController : Controller
    {
        SMSToolEntities db = new SMSToolEntities();
        // GET: SMSConfiguration
        public ActionResult Index()
        {
            ViewBag.ButtonText = "Submit";
            return View();
        }

        [HttpPost]
        public ActionResult Save(SMSConfiguration SMSDetails)
        {
            if (ModelState.IsValid)
            {
                if (Session["Id"] != null)
                {
                    SMSDetails.Id = Convert.ToInt32(Session["Id"]);
                    using (SMSToolEntities db = new SMSToolEntities())
                    {
                        SMSConfiguration updatedDetails = (from c in db.SMSConfigurations
                                                           where c.Id == SMSDetails.Id
                                                           select c).FirstOrDefault();

                        updatedDetails.URL = SMSDetails.URL;
                        updatedDetails.Sender = SMSDetails.Sender;
                        updatedDetails.Route = SMSDetails.Route;
                        updatedDetails.Authkey = SMSDetails.Authkey;
                        updatedDetails.Country = SMSDetails.Country;
                        updatedDetails.Encrypt = SMSDetails.Encrypt;
                        updatedDetails.Flash = SMSDetails.Flash;
                        updatedDetails.Unicode = SMSDetails.Unicode;
                        updatedDetails.Schtime = SMSDetails.Schtime;
                        updatedDetails.Afterminutes = SMSDetails.Afterminutes;
                        updatedDetails.Response = SMSDetails.Response;
                        updatedDetails.Campaign = SMSDetails.Campaign;
                        updatedDetails.UpdatedDate = SMSDetails.UpdatedDate;

                        db.SaveChanges();
                    }

                }
                else
                {
                    SMSDetails.CreatedDate = DateTime.Now;
                    db.SMSConfigurations.Add(SMSDetails);
                    db.SaveChanges();
                }

                ModelState.Clear();
                SMSDetails.Id = 0;
                Session["Id"] = null;
            }
            return View("Index");
        }

        public ActionResult Cancel(SMSConfiguration SMSDetails)
        {
            SMSDetails.Id = 0;
            Session["Id"] = null;
            return View("Index");
        }
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ViewBag.Operation = id;
            ViewBag.Name = db.SMSConfigurations.ToList();

            SMSConfiguration SMSDetails = db.SMSConfigurations.Find(id);
            Session["Id"] = id;
            //objEmp.Id = id;
            ViewBag.ButtonText = "Update";
            return View("Index", SMSDetails);
        }

        public ActionResult Delete(int id)
        {
            SMSConfiguration objEmp = db.SMSConfigurations.Find(id);
            db.SMSConfigurations.Remove(objEmp);
            db.SaveChanges();
            return RedirectToAction("Index", new { id = 0 });
        }
    }
}