﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SMSTool.Models
{
    public class ProcessSMS
    {
        public List<SelectListItem> SenderList { get; set; }
        public List<ProcessSMS> MessageConfig { get; set; }
        public int Id { get; set; }
        public string Sender { get; set; }
        public string Messages { get; set; }
        public bool IsFemale { get; set; }
    }
}