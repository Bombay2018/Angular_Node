﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using System.Net;
using System.IO;
using ExcelDataReader;
using System.Data;
using System.Configuration;

namespace SMSTool.Models
{
    public class ViewModel
    {
        public SMSConfiguration SMSConfig { get; set; }
        public MessageConfiguration MessageConfig { get; set; }
        public int SMSConfigurationId { get; set; }
        public string Message { get; set; }
        public bool IsFemale { get; set; }
    }
}