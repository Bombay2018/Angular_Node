import { Injectable ,EventEmitter} from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

import { Observable, Subject, ReplaySubject, from, of, range } from 'rxjs';
import { map, filter, switchMap } from 'rxjs/operators';
 

import { IUSER_MASTER } from '../shared/interfaces/entities.interface';
import { ConfigService } from '../services/shared/config.service';

@Injectable()
export class UserService<T> {

  private _baseUrl: string = '';
    private _headers: any;

    public user: IUSER_MASTER;
    public sessionEvent: EventEmitter<any>;
    public isAuthenicated: boolean;

    constructor(private http: Http, private configsvc: ConfigService) {
        this.sessionEvent = new EventEmitter();
        this._baseUrl = configsvc.getApiURI();
        this._headers = configsvc.getHTTPHeader();
    }

    getUser(Iuser: IUSER_MASTER): Observable<IUSER_MASTER> {
      debugger;
      let data = {
          "uname": Iuser.user_name,
          "pwd": Iuser.password
      };
      let options = new RequestOptions({ headers: this._headers });
      let body = JSON.stringify(data);

       //     return this.http.get("app/shared/mockdata/user.json")
  //       .map(resp => resp.json() as IUSER_MASTER[]);
      return this.http.get("app/shared/mockdata/user.json")
      .map(resp => resp.json() as IUSER_MASTER[]);
          // .map((res: Response) => {
          //     console.log(res.json().Result[0])
          //     return <IUSER_MASTER>res.json().Result[0];
              // return users.find(obj => obj.user_name == data.user_name && obj.password == data.pwd);
          //});     
  }


  //   getUserfromDB(user: IUSER_MASTER): Observable<IUSER_MASTER> {
  //     let data = {
  //         "username": user.user_name,
  //         "pwd": user.password
  //     }
      
  //     //---------------------------------------------------------------
  //     //  return this.http.get(this._baseUrl)
  //     // .map((response: Response) => <IUSER_MASTER[]> response.json())
  //      // .do(data => console.log(JSON.stringify(data)))
  //     // .catch(this.handleError);

  //     return this.http.get("app/shared/mockdata/user.json")
  //       .map(resp => resp.json() as IUSER_MASTER[]);
  // }
}


// return this.http.post('http://localhost:3000/login', data, {
      //     headers: this._headers
      // })
      //     .map((res: Response) => {
      //         return <IUSER_MASTER>res.json();
      //     });
