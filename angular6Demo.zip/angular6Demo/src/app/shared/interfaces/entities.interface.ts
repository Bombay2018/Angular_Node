export interface IUSER_MASTER{
    user_id: number;
    user_name: string;
    password: string;
    is_active: string;
    created_date?: Date;
    modified_date?: Date;
}
