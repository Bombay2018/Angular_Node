import { Component } from '@angular/core';

import { IUSER_MASTER } from '../app/shared/interfaces/entities.interface';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'UPS IPR';
}
