﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CandidateDetails;
using System.Data.Entity;
using System.Net;
using System.IO;
using ExcelDataReader;
using System.Data;
using System.Configuration;
using System.Data.OleDb;
using System.Data.SqlClient;

namespace CandidateDetails.Models
{
    public class CanditateModel
    {
        ///<summary>
        /// Gets or sets Customers.
        ///</summary>
        public List<CandidateDetail> CandidateDetails { get; set; }
        public int Id { get; set; }
        public string Name { get; set; }
        public byte[] Photo { get; set; }
        public string Address { get; set; }
        public string JobProfile { get; set; }
        public string email { get; set; }
        public Nullable<int> phone { get; set; }
        public string pahtphoto { get; set; }
        ///<summary>
        /// Gets or sets CurrentPageIndex.
        ///</summary>
        public int CurrentPageIndex { get; set; }

        ///<summary>
        /// Gets or sets PageCount.
        ///</summary>
        public int PageCount { get; set; }
    }
}