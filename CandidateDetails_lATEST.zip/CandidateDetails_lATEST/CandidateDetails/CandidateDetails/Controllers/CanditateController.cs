﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CandidateDetails;
using System.Data.Entity;
using System.Net;
using System.IO;
using ExcelDataReader;
using System.Data;
using System.Configuration;
using System.Data.OleDb;
using System.Data.SqlClient;
using PagedList;
using CandidateDetails.Models;

namespace CandidateDetails.Controllers
{
    public class CanditateController : Controller
    {
        CandidateEntities db = new CandidateEntities();
        // GET: Canditate
        public ActionResult Index()
        {  
            ViewBag.ButtonText = "Submit";
            return View(this.GetCanditate(1));
        }

        [HttpPost]
        public ActionResult Index(int currentPageIndex)
        {
            return View(this.GetCanditate(currentPageIndex));
        }

        private CanditateModel GetCanditate(int currentPage)
        {
            int maxRows = 1;
            using (CandidateEntities db = new CandidateEntities())
            {
                CanditateModel CanditateModel = new CanditateModel();

                CanditateModel.CandidateDetails = (from c in db.CandidateDetails
                                           select c)
                            .OrderBy(c => c.Id)
                            .Skip((currentPage - 1) * maxRows)
                            .Take(maxRows).ToList();

                double pageCount = (double)((decimal)db.CandidateDetails.Count() / Convert.ToDecimal(maxRows));
                CanditateModel.PageCount = (int)Math.Ceiling(pageCount);

                CanditateModel.CurrentPageIndex = currentPage;

                return CanditateModel;
            }
        }


        [HttpGet]
        public ActionResult Search(string Name)
        {
            if (Name == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            //CandidateDetail objEmp = db.CandidateDetails.Where(s => s.Name.Contains(Name));
            var objEmp = db.CandidateDetails.Where(stu => stu.Name.ToUpper().Contains(Name.ToUpper()));

            if (objEmp == null)
            {
                return HttpNotFound();
            }
            return View("Index", objEmp.ToList());
            //return RedirectToAction("Index", objEmp.ToList());
        }
        
        [HttpPost]
        public ActionResult Save(CandidateDetail Details, HttpPostedFileBase File1, HttpPostedFileBase File2)
        {
            if (ModelState.IsValid)
            {

                if (Session["Id"]!=null/*Details !=null && Details.Id != 0*/)
                {
                    if (File1 != null && File1.ContentLength > 0 && File2 != null)
                    {
                        Details.Photo = new byte[File1.ContentLength]; // file1 to store image in binary formate  
                        File1.InputStream.Read(Details.Photo, 0, File1.ContentLength);
                        string ImageName = System.IO.Path.GetFileName(File2.FileName); //file2 to store path and url  
                        string physicalPath = Server.MapPath("~/img/" + ImageName);
                        // save image in folder  
                        File2.SaveAs(physicalPath);
                        // store path in database  
                        Details.pahtphoto = "img/" + ImageName;
                      
                    }
                    Details.Id = Convert.ToInt32(Session["Id"]);
                    using (CandidateEntities entities = new CandidateEntities())
                    {
                        CandidateDetail updatedCustomer = (from c in entities.CandidateDetails
                                                           where c.Id == Details.Id
                                                           select c).FirstOrDefault();
                        updatedCustomer.Name = Details.Name;
                        updatedCustomer.Photo = Details.Photo;
                        updatedCustomer.Address = Details.Address;
                        updatedCustomer.JobProfile = Details.JobProfile;
                        updatedCustomer.email = Details.email;
                        updatedCustomer.phone = Details.phone;
                        updatedCustomer.pahtphoto = Details.pahtphoto;
                        entities.SaveChanges();
                        ModelState.Clear();
                    }
                    Details.Id = 0;
                    Session["Id"] = null;
                    return View();
                }
                else
                {
                   
                    if (File1 != null && File1.ContentLength > 0 && File2 != null)
                    {
                        Details.Photo = new byte[File1.ContentLength]; // file1 to store image in binary formate  
                        File1.InputStream.Read(Details.Photo, 0, File1.ContentLength);
                        string ImageName = System.IO.Path.GetFileName(File2.FileName); //file2 to store path and url  
                        string physicalPath = Server.MapPath("~/img/" + ImageName);
                        // save image in folder  
                        File2.SaveAs(physicalPath);
                        // store path in database  
                        Details.pahtphoto = "img/" + ImageName;
                        db.CandidateDetails.Add(Details);
                        db.SaveChanges();

                        ModelState.Clear();
                    }
                    return View();
                }
            }
            else
            {
                return View();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ViewBag.Operation = id;
            ViewBag.Name = db.CandidateDetails.ToList();

            CanditateModel CanditateModel = new CanditateModel();
            CanditateModel.CandidateDetails = (from c in db.CandidateDetails
                                                where c.Id==id
                                                select c).ToList();

            Session["Id"] = id;
            //objEmp.Id = id;
            ViewBag.ButtonText = "Update";
            return View("Index", CanditateModel);
        }

        public ActionResult Delete(int id)
        {
            CandidateDetail objEmp = db.CandidateDetails.Find(id);
            db.CandidateDetails.Remove(objEmp);
            db.SaveChanges();
            return RedirectToAction("Index", new { id = 0 });
        }

        public ActionResult Cancel(CandidateDetail Details)
        {
            Details.Id = 0;
            Session["Id"] = null;
            return View("Index");
        }

        public ActionResult Candetail()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Upload(HttpPostedFileBase upload)
        {
            if (ModelState.IsValid)
            {

                if (upload != null && upload.ContentLength > 0)
                {
                    // ExcelDataReader works with the binary Excel file, so it needs a FileStream
                    // to get started. This is how we avoid dependencies on ACE or Interop:
                    Stream stream = upload.InputStream;

                    // We return the interface, so that
                    IExcelDataReader reader = null;


                    if (upload.FileName.EndsWith(".xls"))
                    {
                        reader = ExcelReaderFactory.CreateBinaryReader(stream);
                    }
                    else if (upload.FileName.EndsWith(".xlsx"))
                    {
                        reader = ExcelReaderFactory.CreateOpenXmlReader(stream);
                    }
                    else
                    {
                        ModelState.AddModelError("File", "This file format is not supported");
                        return View();
                    }

                    //reader.IsFirstRowAsColumnNames = true;
                    var conf = new ExcelDataSetConfiguration
                    {
                        ConfigureDataTable = _ => new ExcelDataTableConfiguration
                        {
                            UseHeaderRow = true
                        }
                    };

                    DataSet result = reader.AsDataSet();
                    result.Tables[0].Rows[0].Delete();
                    result.Tables[0].AcceptChanges();
                    reader.Close();

                    return View("Candetail", result.Tables[0]);
                }
                else
                {
                    ModelState.AddModelError("File", "Please Upload Your file");
                }
            }
            return View("Candetail");
        }

        public ActionResult Detail()
        {
            return View();
        }

        bool CustName;
        bool EmailId;
        bool ContactNo;
        
        [HttpPost]
        public ActionResult DetailUpload(HttpPostedFileBase postedFile)
        {
            ViewBag.ErrorMessage = "";
            string filePath = string.Empty;
            if (postedFile != null)
            {
                string path = Server.MapPath("~/Uploads/");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                filePath = path + Path.GetFileName(postedFile.FileName);
                string extension = Path.GetExtension(postedFile.FileName);
                postedFile.SaveAs(filePath);

                string conString = string.Empty;
                switch (extension)
                {
                    case ".xls": //Excel 97-03.
                        conString = ConfigurationManager.ConnectionStrings["Excel03ConString"].ConnectionString;
                        break;
                    case ".xlsx": //Excel 07 and above.
                        conString = ConfigurationManager.ConnectionStrings["Excel07ConString"].ConnectionString;
                        break;
                }

                DataTable dt = new DataTable();
                conString = string.Format(conString, filePath);

                using (OleDbConnection connExcel = new OleDbConnection(conString))
                {
                    using (OleDbCommand cmdExcel = new OleDbCommand())
                    {
                        using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                        {
                            cmdExcel.Connection = connExcel;

                            //Get the name of First Sheet.
                            connExcel.Open();
                            DataTable dtExcelSchema;
                            dtExcelSchema = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                            string sheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();
                            connExcel.Close();

                            //Read Data from First Sheet.
                            connExcel.Open();
                            cmdExcel.CommandText = "SELECT * From [" + sheetName + "]";
                            odaExcel.SelectCommand = cmdExcel;
                            odaExcel.Fill(dt);
                            connExcel.Close();
                        }
                    }
                }
              
                conString = ConfigurationManager.ConnectionStrings["Constring"].ConnectionString;
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(con))
                    {
                        //Set the database table name.
                        sqlBulkCopy.DestinationTableName = "dbo.Customers";

                        //[OPTIONAL]: Map the Excel columns with that of the database table
                        //sqlBulkCopy.ColumnMappings.Add("CustomerId", "CustomerId");
                        sqlBulkCopy.ColumnMappings.Add("Name", "Name");
                        sqlBulkCopy.ColumnMappings.Add("Country", "Country");
                        sqlBulkCopy.ColumnMappings.Add("EmailId", "EmailId");
                        sqlBulkCopy.ColumnMappings.Add("ContactNo", "ContactNo");

                        con.Open();

                        foreach (var col in db.Customers)
                        {
                            CustName = dt.Select().ToList().Exists(row => row["Name"].ToString().ToUpper() == col.Name.ToString().ToUpper());
                            EmailId = dt.Select().ToList().Exists(row => row["EmailId"].ToString().ToUpper() == col.EmailId.ToString().ToUpper());
                            ContactNo = dt.Select().ToList().Exists(row => row["ContactNo"].ToString().ToUpper() == col.ContactNo.ToString().ToUpper());

                            if (CustName || EmailId || ContactNo)
                            {
                                if(CustName)
                                ViewBag.ErrorMessage = "Customer Name:" + col.Name + " | ";
                                if (EmailId)
                                ViewBag.ErrorMessage += "Email Id:" + col.EmailId + " | ";
                                if (ContactNo)
                                ViewBag.ErrorMessage += "Contact No:" + col.ContactNo;

                                ViewBag.ErrorMessage += " is duplicate in uploaded sheet";
                                return View("Detail");
                            }
                        }        
                          sqlBulkCopy.WriteToServer(dt);
                          con.Close();
                          ViewBag.ErrorMessage = "File Uploaded Successfully...!!";
                    }
                }
            }
            else
            {
                ViewBag.ErrorMessage = "Please Select Files!!";
                return View("Detail");
            }

            return View("Detail");
        }

    }
}
