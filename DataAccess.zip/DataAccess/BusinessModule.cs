﻿using BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    public class BusinessModule
    {
        public static List<Phone> Contacts;
        public static List<LoginDetailInput> LoginDetails;

        public BusinessModule()
        {            
            Contacts = new List<Phone>();
            Contacts.Add(new Phone { UserId = 1000, AlternateMobileNumber = 12312312, PhoneNumber = 214321423 });
            Contacts.Add(new Phone { UserId = 1001, AlternateMobileNumber = 12312312, PhoneNumber = 214321423 });
            Contacts.Add(new Phone { UserId = 1002, AlternateMobileNumber = 12312312, PhoneNumber = 214321423 });
            Contacts.Add(new Phone { UserId = 1002, AlternateMobileNumber = 12312312, PhoneNumber = 214321423 });

            LoginDetails = new List<LoginDetailInput>();
            LoginDetails.Add(new LoginDetailInput { FullName = "Jagdish sahu", Password = "test!123", Role = "Tester", Username = "ABC", UserId = 1000 });
            LoginDetails.Add(new LoginDetailInput { FullName = "Bharat Taksalia", Password = "test!1234", Role = "Developer", Username = "DEF", UserId = 1001 });
            LoginDetails.Add(new LoginDetailInput { FullName = "Ram shyam", Password = "test!12345", Role = "Manager", Username = "GHI", UserId = 1002 });
            LoginDetails.Add(new LoginDetailInput { FullName = "gaga baba", Password = "test!123456", Role = "Analyst", Username = "JKL", UserId = 1003 });
        }
    }
}
