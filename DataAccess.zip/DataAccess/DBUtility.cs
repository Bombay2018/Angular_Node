﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    public class DBUtility
    {
        #region All Constructor(s)

        // Default Constructor
        public DBUtility()
        {
            this.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        }

        public DBUtility(string ConnectionString)
        {
            this.sqlConnection = new SqlConnection(ConnectionString);
        }

        #endregion

        #region All Properties


        private string connectionString;
        public string ConnectionString
        {
            set
            {
                connectionString = value;
            }
        }

        public SqlConnection sqlConnection { get; set; }

        public SqlCommand sqlCommand { get; set; }

        public SqlDataAdapter dataAdapter { get; set; }

        public DataSet dataSet { get; set; }

        #endregion

        #region All Private Method(s)

        private void OpenConnection()
        {
            if (sqlConnection == null)
            {
                sqlConnection = new SqlConnection(connectionString);
            }

            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }

            // Initialization Command Object
            sqlCommand = new SqlCommand();

            // set active Connection to Command Object
            sqlCommand.Connection = sqlConnection;
        }

        private void CloseConnection()
        {
            if (sqlConnection.State == ConnectionState.Open)
            {
                sqlConnection.Close();
            }
        }

        private void DisposeConnection()
        {
            if (sqlConnection != null)
            {
                sqlConnection.Dispose();
                sqlConnection = null;
            }
        }
        #endregion

        #region All Public Method(s)

        /// <summary>
        /// 
        /// </summary>
        /// <param name="spName"></param>
        /// <param name="sqlParameters"></param>
        /// <param name="sortColumn"></param>
        /// <returns></returns>
        public DataTable GetDataTable(string spName, string sortColumn)
        {
            DataTable dt = new DataTable();
            try
            {
                OpenConnection();
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.CommandText = spName;
                dataAdapter = new SqlDataAdapter();
                dataAdapter.SelectCommand = sqlCommand;
                dataAdapter.Fill(dt);

                if (!string.IsNullOrWhiteSpace(sortColumn))
                {
                    dt.DefaultView.Sort = sortColumn;
                    dt = dt.DefaultView.ToTable();
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
                DisposeConnection();
            }
            return dt;
        }
        public DataTable GetDataTable(string spName, List<SqlParameter> sqlParameters, string sortColumn)
        {
            DataTable dt = new DataTable();
            try
            {
                OpenConnection();
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.CommandText = spName;
                sqlCommand.CommandTimeout = 100000;
                dataAdapter = new SqlDataAdapter();
                if (sqlParameters != null)
                {
                    foreach (SqlParameter param in sqlParameters)
                    {
                        sqlCommand.Parameters.Add(param);
                    }
                }

                dataAdapter.SelectCommand = sqlCommand;
                dataAdapter.Fill(dt);

                if (!string.IsNullOrWhiteSpace(sortColumn))
                {
                    dt.DefaultView.Sort = sortColumn;
                    dt = dt.DefaultView.ToTable();
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
                DisposeConnection();
            }
            return dt;
        }

        public DataTable GetDataFromDataReader(string spName, List<SqlParameter> sqlParameters, string sortColumn)
        {
            DataTable dt = new DataTable();
            try
            {
                OpenConnection();
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.CommandText = spName;
                sqlCommand.CommandTimeout = 1000000;
                if (sqlParameters != null)
                {
                    foreach (SqlParameter param in sqlParameters)
                    {
                        sqlCommand.Parameters.Add(param);
                    }
                }

                SqlDataReader dr = sqlCommand.ExecuteReader(CommandBehavior.CloseConnection);
                DataTable dtSchema = dr.GetSchemaTable();

                List<DataColumn> listCols = new List<DataColumn>();

                if (dtSchema != null)
                {
                    foreach (DataRow drow in dtSchema.Rows)
                    {
                        string columnName = System.Convert.ToString(drow["ColumnName"]);
                        DataColumn column = new DataColumn(columnName, (Type)(drow["DataType"]));
                        listCols.Add(column);
                        dt.Columns.Add(column);
                    }
                }

                while (dr.Read())
                {
                    DataRow dataRow = dt.NewRow();
                    for (int i = 0; i < listCols.Count; i++)
                    {
                        dataRow[((DataColumn)listCols[i])] = dr[i];
                    }
                    dt.Rows.Add(dataRow);
                }

                if (!string.IsNullOrWhiteSpace(sortColumn))
                {
                    dt.DefaultView.Sort = sortColumn;
                    dt = dt.DefaultView.ToTable();
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConnection();
                DisposeConnection();
            }
            return dt;
        }

        /// <summary>
        /// This Method read data from a data source by using  SqlDataAdapter.
        /// </summary>
        /// <param name="spName">string</param>
        /// <param name="arrPrams">Array Of SqlParameter</param>
        /// <returns>DataTable</returns>
        public List<DataRow> GetList(string spName, SqlParameter[] arrPrams)
        {
            OpenConnection();
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.CommandText = spName;

            dataAdapter = new SqlDataAdapter();
            if (arrPrams != null)
            {
                foreach (SqlParameter param in arrPrams)
                {
                    sqlCommand.Parameters.Add(param);
                }
                dataAdapter.SelectCommand = sqlCommand;
            }
            //Transfer the data into DataTable
            DataTable dt = new DataTable();
            dataAdapter.Fill(dt);
            CloseConnection();
            DisposeConnection();
            List<DataRow> list = dt.AsEnumerable().ToList();
            return list;
        }

        /// <summary>
        /// This Method read data from a data source by using  SqlDataAdapter.
        /// </summary>
        /// <param name="spName">string</param>
        /// <param name="arrPrams">Array Of SqlParameter</param>
        /// <returns>DataSet</returns>
        public DataSet GetDataSet(string strsql, SqlParameter[] arrPrams)
        {
            OpenConnection();
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.CommandText = strsql;
            sqlCommand.CommandTimeout = 100000;
            dataAdapter = new SqlDataAdapter(strsql, sqlConnection);
            if (arrPrams != null)
            {
                foreach (SqlParameter param in arrPrams)
                {
                    sqlCommand.Parameters.Add(param);
                }
                dataAdapter.SelectCommand = sqlCommand;
            }
            dataSet = new DataSet();
            dataAdapter.Fill(dataSet, strsql);
            CloseConnection();
            DisposeConnection();
            return dataSet;
        }

        public int ExecuteSql(string spName, SqlParameter[] arrPrams)
        {
            OpenConnection();
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.CommandText = spName;
            if (arrPrams != null)
            {
                sqlCommand.Parameters.Clear();
                foreach (SqlParameter param in arrPrams)
                {
                    sqlCommand.Parameters.Add(param);
                }
            }
            int result = sqlCommand.ExecuteNonQuery();
            CloseConnection();
            DisposeConnection();
            return result;
        }

        public string ExecuteScalar(string spName, SqlParameter[] arrPrams)
        {
            OpenConnection();
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.CommandText = spName;
            if (arrPrams != null)
            {
                sqlCommand.Parameters.Clear();
                foreach (SqlParameter param in arrPrams)
                {
                    sqlCommand.Parameters.Add(param);
                }
            }
            string result = sqlCommand.ExecuteScalar().ToString();
            CloseConnection();
            DisposeConnection();
            return result;
        }

        public string ExecuteNonQuery(string spName, List<SqlParameter> inputParams, SqlParameter outPutParameter)
        {
            string OutputMessage = string.Empty;
            OpenConnection();
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.CommandText = spName;
            if (inputParams != null)
            {
                sqlCommand.Parameters.Clear();
                foreach (SqlParameter param in inputParams)
                {
                    sqlCommand.Parameters.Add(param);
                }
            }
            if (outPutParameter != null)
            {
                sqlCommand.Parameters.Add(outPutParameter);
            }
            sqlCommand.ExecuteNonQuery();
            if (outPutParameter != null)
            {
                OutputMessage = outPutParameter.Value.ToString();
            }
            CloseConnection();
            DisposeConnection();
            return OutputMessage;
        }
        #endregion
    }
}
