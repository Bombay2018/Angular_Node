﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObjects
{
   public  class Phone
    {

       
        public int UserId { get; set; } 

        public int PhoneNumber { get; set; }

        public int AlternateMobileNumber { get; set; }
    }
}
