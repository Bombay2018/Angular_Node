﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using Unity;
using Unity.AspNet.Mvc;
using Unity.RegistrationByConvention;

namespace Infrastructure
{
    public class Bootstrapper
    {
        public static IUnityContainer Initialise()
        {
            var container = BuildUnityContainer();
            DependencyResolver.SetResolver(new UnityDependencyResolver(container));
            return container;
        }

        static Assembly GetAssemblyByName(string name)
        {
            return AppDomain.CurrentDomain.GetAssemblies().
                       SingleOrDefault(assembly => assembly.GetName().Name == name);
        }

        public static IEnumerable<Assembly> LoadAssemblies()
        {
            DirectoryInfo directory = new DirectoryInfo(System.AppDomain.CurrentDomain.BaseDirectory);
            FileInfo[] files = directory.GetFiles("*.dll", SearchOption.AllDirectories);

            foreach (FileInfo file in files.Where(x => x.Name == "BusinessLogic.dll" || x.Name == "DataAccess.dll"))
            {
                // Load the file into the application domain.
                AssemblyName assemblyName = AssemblyName.GetAssemblyName(file.FullName);
                Assembly assembly = AppDomain.CurrentDomain.Load(assemblyName);
                yield return assembly;
            }

            yield break;
        }

        private static IUnityContainer BuildUnityContainer()
        {
            // var aa = GetAssemblyByName("UVSS.Business");

            using (var container = new UnityContainer())
            {
                container.RegisterTypes(
                   AllClasses.FromAssemblies(LoadAssemblies()),
                   WithMappings.FromMatchingInterface,
                   WithName.Default,
                   WithLifetime.PerResolve);

                RegisterTypes(container);
                return container;
            }
        }
        public static void RegisterTypes(IUnityContainer container)
        {
            //container.RegisterType<IUserManagementService, UserManagementService>();
            //container.RegisterType<ILPRManagementService, LPRManagementService>();
            //container.RegisterType<IUnitOfWork, UnitOfWork>();
        }
    }
}
