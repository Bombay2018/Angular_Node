﻿using BusinessObjects;
using DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public class FreightDetails : IFreightDetails
    {
        IUnitOfWork unitOfWork;
        private Repository<tblOrder> OrdersRepository;
        private Repository<tblShipper> ShippersRepository;
        private Repository<tblCustomer> CustomerRepository;
        private Repository<tblOrderDetailLineItem> OrderDetailLineItemRepository;

        public FreightDetails(IUnitOfWork _unitOfWork)
        {
            unitOfWork = _unitOfWork;
            OrdersRepository = unitOfWork.Repository<tblOrder>();
            ShippersRepository = unitOfWork.Repository<tblShipper>();
            CustomerRepository = unitOfWork.Repository<tblCustomer>();
            OrderDetailLineItemRepository = unitOfWork.Repository<tblOrderDetailLineItem>();
        }


        public FreightRateRequestInputDto GetFreightRequestParams(int orderId)
        {
            var result = from o in OrdersRepository.AsQueryable()
                         join s in ShippersRepository.AsQueryable() on o.ShipmentId equals s.ShipmentId
                         join c in CustomerRepository.AsQueryable() on o.CustomerId equals c.CustomerId
                         join od in OrderDetailLineItemRepository.AsQueryable() on o.OrderId equals od.OrderId
                         where o.OrderId.Equals(orderId)
                         select new FreightRateRequestInputDto
                         {
                            ShipTimeStamp = s.ShipTimestamp.Value,
                            ShipTimeStampSpecified = s.ShipTimestampSpecified.Value,
                             //DropOffType = s.DropoffType,
                             //ServiceType = s.ServiceType,
                             ServiceTypeSpecified = s.ServiceTypeSpecified.Value,
                             //PackagingType = s.PackagingType,
                             PackagingTypeSpecified = s.PackagingTypeSpecified.Value,

                             Shipper =  new Shipper
                             {
                                 ShipperAddress =  new Address
                                 {
                                     City = s.City,
                                     CountryCode = s.CountryCode,
                                     PostalCode = s.PostalCode,
                                     StateOrProvinceCode = s.StateOrProvinceCode,
                                     StreetLines = s.StreetLines
                                 }

                             }                             
                             //senderCity = s.City,
                             //senderCode = s.PostalCode,
                             //senderStreet = s.StreetLines,
                             //senderState = s.StateOrProvinceCode,
                             //senderCountry = s.CountryCode,
                             //recipientCity = c.City,
                             //recipientCode = c.PostalCode,
                             //recipientStreet = c.StreetLines,
                             //recipientState = c.StateOrProvinceCode,
                             //recipientCountry = c.CountryCode,
                             //shipPaymentType = o.PaymentType,
                             //shipPaymentTypeSpecified = o.PaymentTypeSpecified,
                             //payorResponsiblePartyAcc = s.ResponsiblePartyAccountNumber,
                             //payorResponsibilityContact = s.ResponsiblePartyContactPhone,
                             //payorResponsibleCity = s.ResponsiblePartyCity,
                             //payorResponsibilityState = s.ResponsiblePartyStateOrProvinceCode,
                             //payorResponsibilityCode = s.ResponsiblePartyCountryCode,
                             //payorResponsibilityCountry = s.ResponsiblePartyCountryCode,
                             //payorResponsibilityStreet = s.ResponsiblePartyStreetLines,
                             //od.FedExFreightAccountNumber,
                             //freightShipRole = od.Role,
                             //freightShipRoleSpcified = od.RoleSpecified,
                             //freightShipHandlingUnits = od.TotalHandlingUnits,
                             //LiabilityCoverageType = od.CoverageType,
                             //liabilityCoverageTypeSpecified = od.CoverageTypeSpecified,
                             //liabilityAmountSpecified = od.CoverageAmountSpecified,
                             //liabilityAmount = od.CoverageAmount,
                             //liabilityCoverageCurrency = od.CoverageCurrency,
                             //freightShipDimensionHeight = od.DimensionsHeight,
                             //freightShipDimensionLength = od.DimensionsLength,
                             //freightShipDimensionWidth = od.DimensionsWidth,
                             //freightShipDimensionUnit = od.DimensionsUnit,
                             //freightShipDimensionUnitSpecified = od.DimensionsUnitsSpecified,
                             //od.FreightClass,
                             //od.FreightClassSpecified,
                             //od.Packaging,
                             //od.PackagingSpecified,
                             //od.Description,
                             //od.WeightUnit,
                             //od.WeightUnitsSpecified,
                             //od.WeightValue,
                             //od.WeightValueSpecified,
                             //od.DimensionsHeight,
                             //od.DimensionsLength,
                             //od.DimensionsUnit,
                             //od.DimensionsUnitsSpecified,
                             //od.DimensionsWidth,
                             //od.VolumeUnits,
                             //od.VolumeUnitsSpecified,
                             //od.VolumeValue,
                             //od.VolumeValueSpecified
                         };

            return result.FirstOrDefault();
        }
    }
}
