﻿using BusinessLogic;
using BusinessObjects;
using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPI_POC1.BusinessIntegrator; 

namespace WebAPI_POC1.Controllers
{
    [RoutePrefix("api")]
    public class LoginController : ApiController
    {
        private readonly IUserManagement _UserManagement;
        public LoginController(IUserManagement userManagement)
        {
            this._UserManagement = userManagement;
        }

        [HttpPost]
        [Route("authenticate")]
        public HttpResponseMessage Authenticate(LoginDetailInput login)
        {
            try
            {  
                LoginDetailOutput output = _UserManagement.PostLogin(login);
                return Request.CreateResponse(HttpStatusCode.OK, login);
            }
            catch (Exception e)
            {
                var response = new HttpResponseMessage(HttpStatusCode.Conflict);
                response.Content = new StringContent(e.Message);
                throw new HttpResponseException(response);
            }
        }


        //[HttpPost]
        //[Route("authenticate")]
        //public HttpResponseMessage Authenticate(LoginDetailInput login)
        //{
        //    try
        //    {
        //        LoginDetailOutput output = BusinessModule.PostLogin(login);
        //        return Request.CreateResponse(HttpStatusCode.OK, login);
        //    }
        //    catch (Exception e)
        //    {
        //        var response = new HttpResponseMessage(HttpStatusCode.Conflict);
        //        response.Content = new StringContent(e.Message);
        //        throw new HttpResponseException(response);
        //    }
        //}


    }
}
