﻿using BusinessLogic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace WebAPI_POC1.Controllers
{
    [RoutePrefix("api")]
    public class FreightRateController : ApiController
    {
        public IFreightDetails FreightDetails;

        public FreightRateController(IFreightDetails _FreightDetails)
        {
            this.FreightDetails = _FreightDetails;
        }

        [HttpGet]
        [Route("FreightRateRequest/{id}")]
        public HttpResponseMessage Get(int id)
        {
            var freightRateRequestInputDto = FreightDetails.GetFreightRequestParams(id);

            if (freightRateRequestInputDto != null)
                return Request.CreateResponse(HttpStatusCode.OK, freightRateRequestInputDto);
            else
            {
                var response = new HttpResponseMessage(HttpStatusCode.NotFound);
                response.Content = new StringContent("Freight rate request not found");
                throw new HttpResponseException(response);
            }
        }
    }
}
