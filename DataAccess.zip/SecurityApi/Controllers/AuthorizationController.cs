﻿using SecurityApi.Entities;
using SecurityApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace SecurityApi.Controllers
{
    [RoutePrefix("api")]
    public class AuthorizationController : ApiController
    {

        //public IContactDetails ContactDetails;

        //public PhoneController(IContactDetails _ContactDetails)
        //{
        //    this.ContactDetails = _ContactDetails;
        //}

        [HttpPost]
        [Route("test")]
        public HttpResponseMessage Authorization()
        {
            try
            {
                //LoginDetailOutput output = _UserManagement.PostLogin(login);
                return Request.CreateResponse(HttpStatusCode.OK, "Authorized Successfully");
            }
            catch (Exception e)
            {
                var response = new HttpResponseMessage(HttpStatusCode.Conflict);
                response.Content = new StringContent(e.Message);
                throw new HttpResponseException(response);
            }
        }


        [Route("Authorization")]
        public IHttpActionResult Post(AudienceModel audienceModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            Audience newAudience = AudiencesStore.AddAudience(audienceModel.Name);

            return Ok<Audience>(newAudience);

        }
    }
}
