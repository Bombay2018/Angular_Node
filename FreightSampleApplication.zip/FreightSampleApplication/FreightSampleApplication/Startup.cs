﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(FreightSampleApplication.Startup))]
namespace FreightSampleApplication
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
