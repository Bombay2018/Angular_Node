﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using FreightSampleApplication.DataAccessLayer;

namespace FreightSampleApplication.Controllers
{
    public class CustomerController : Controller
    {
        private FreightEntities db = new FreightEntities();

        // GET: Customer
        public ActionResult RequestFreightQuote()
        {
            var customers = db.Customers;


            IEnumerable<SelectListItem> selectCustomerList = customers.Select(c => new SelectListItem
            {
                Value = c.CustomerId.ToString(),
                Text = c.CustomerName
            });

            IEnumerable<SelectListItem> selectProviderList = customers.Select(c => new SelectListItem
            {
                Value = c.ProviderId.ToString(),
                Text = c.Provider.Provider1
            });

            IEnumerable<SelectListItem> selectOderList = db.OrderDetailLineItems.Select(c => new SelectListItem
            {
                Value = c.OrderDetailId.ToString(),
                Text = c.FreightClass
            });

            ViewBag.Customers = new SelectList(selectCustomerList, "Value", "Text");
            ViewBag.Providers = new SelectList(selectProviderList, "Value", "Text");
            ViewBag.Orders = new SelectList(selectOderList, "Value", "Text");

            return View();
        }

        public JsonResult GetCustomerDetails(int customerId)
        {
            Customer customerProvider = db.Customers.Find(customerId);

            Order customerOrder = db.Orders.Where(x => x.CustomerId == customerId).SingleOrDefault();
            OrderDetailLineItem lineItem = db.OrderDetailLineItems.Where(o => o.OrderId == customerOrder.OrderId).SingleOrDefault();

            if (customerProvider != null)
            {
                return Json(new
                {
                    result = true,
                    providerId = customerProvider.ProviderId,
                    lineItemID = lineItem.OrderDetailId
                }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(new { result = false }, JsonRequestBehavior.AllowGet);
            }
        }
        
        //----------Unwanted Code------------//

        // GET: Customer
        public ActionResult Index()
        {
            var customers = db.Customers.Include(c => c.ApiAccessRule).Include(c => c.Configuration).Include(c => c.Provider);
            return View(customers.ToList());
        }

        // GET: Customer/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer customer = db.Customers.Find(id);
            if (customer == null)
            {
                return HttpNotFound();
            }
            return View(customer);
        }

        // GET: Customer/Create
        public ActionResult Create()
        {
            ViewBag.APIRuleId = new SelectList(db.ApiAccessRules, "Id", "Rules");
            ViewBag.ConfiguratonId = new SelectList(db.Configurations, "Id", "ConfigurationKey");
            ViewBag.ProviderId = new SelectList(db.Providers, "Id", "Provider1");
            return View();
        }

        // POST: Customer/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "CustomerId,CustomerName,UserName,Password,AcountNumber,MeterNumber,Preferenece,PriorityOptions,Margin,StreetLines,City,StateOrProvinceCode,CountryCode,PostalCode,ProviderId,ConfiguratonId,APIRuleId,IsActive")] Customer customer)
        {
            if (ModelState.IsValid)
            {
                db.Customers.Add(customer);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.APIRuleId = new SelectList(db.ApiAccessRules, "Id", "Rules", customer.APIRuleId);
            ViewBag.ConfiguratonId = new SelectList(db.Configurations, "Id", "ConfigurationKey", customer.ConfiguratonId);
            ViewBag.ProviderId = new SelectList(db.Providers, "Id", "Provider1", customer.ProviderId);
            return View(customer);
        }

        // GET: Customer/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer customer = db.Customers.Find(id);
            if (customer == null)
            {
                return HttpNotFound();
            }
            ViewBag.APIRuleId = new SelectList(db.ApiAccessRules, "Id", "Rules", customer.APIRuleId);
            ViewBag.ConfiguratonId = new SelectList(db.Configurations, "Id", "ConfigurationKey", customer.ConfiguratonId);
            ViewBag.ProviderId = new SelectList(db.Providers, "Id", "Provider1", customer.ProviderId);
            return View(customer);
        }

        // POST: Customer/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "CustomerId,CustomerName,UserName,Password,AcountNumber,MeterNumber,Preferenece,PriorityOptions,Margin,StreetLines,City,StateOrProvinceCode,CountryCode,PostalCode,ProviderId,ConfiguratonId,APIRuleId,IsActive")] Customer customer)
        {
            if (ModelState.IsValid)
            {
                db.Entry(customer).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.APIRuleId = new SelectList(db.ApiAccessRules, "Id", "Rules", customer.APIRuleId);
            ViewBag.ConfiguratonId = new SelectList(db.Configurations, "Id", "ConfigurationKey", customer.ConfiguratonId);
            ViewBag.ProviderId = new SelectList(db.Providers, "Id", "Provider1", customer.ProviderId);
            return View(customer);
        }

        // GET: Customer/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer customer = db.Customers.Find(id);
            if (customer == null)
            {
                return HttpNotFound();
            }
            return View(customer);
        }

        // POST: Customer/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Customer customer = db.Customers.Find(id);
            db.Customers.Remove(customer);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
