
-- =============================================
-- Author:		Dasharath
-- Create date: 29-Jan-2018
-- Description:	Authentcate user
-- =============================================
ALTER PROCEDURE AuthenticateUser
	@LoginID VARCHAR(20),
	@Password NVARCHAR(50)
AS
BEGIN
	SET NOCOUNT ON;

    SELECT TOP 1 UserName 
    FROM UserDetails
    WHERE UserName=@LoginID
    AND [Password]=@Password
    
END
GO
