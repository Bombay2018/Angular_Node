//Exporting a complete object

module.exports={

 printAvatar: function(){

    console.log("Avatar");

},


 printMatrix: function(){

    console.log("Matrix");

},

favMovie:'Note Book'

}