const movie=requie('./movie');

movie.printAvatar();
movie.printMatrix();

movie.favMovie="New Movoe";
console.log(movie.favMovie); 