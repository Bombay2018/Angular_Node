//function callback(){

//console.log("My call back is being deffered!!!");
//}


//setTimeout(callback,5000)

//console.log("I am at the end!!!");


//OR


setTimeout(function callback(){

console.log("My call back is being deffered!!!");
},5000);


console.log("I am at the end!!!");
// asynch and non blocking
// one thread can serve lots of apps


