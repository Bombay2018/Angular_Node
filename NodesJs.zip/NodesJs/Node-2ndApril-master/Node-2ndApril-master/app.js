
function sayHello(name) {
	console.log("Hello::" + name);
}

sayHello("Yukti");

var message = "Good Evevening";

//Global variable
console.log(module);
console.log("File name" + __filename);
console.log("Dirname" + __dirname);

// import a module: require 
const logger = require('./loggerModule'); // refer logger object and file name
logger.logMsg('Checking for custom module');