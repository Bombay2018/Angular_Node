// exporting a complete object
module.exports = {
	printAvatar : function() {
		console.log("Avatar");
	},
	
	printMatrix : function() {
		console.log("Marix");
	},
	
	favMovie:'Note Book'
}