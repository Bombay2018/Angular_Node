// creating a module
function logMessage(message) {
	console.log(message);
}

// exporting a module
module.exports.logMsg = logMessage;