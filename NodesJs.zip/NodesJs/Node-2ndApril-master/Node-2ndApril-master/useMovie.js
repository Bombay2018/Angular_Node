const movie = require('./movie');
movie.printAvatar();
movie.printMatrix();

movie.favMovie="Iron Man";
console.log(movie.favMovie);