// CREATING MODULE

function log(message){

console.log(message);

}


//EXPORTING MODULE
module.exports.log1=log;