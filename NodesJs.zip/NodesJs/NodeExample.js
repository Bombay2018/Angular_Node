1.How to hanlde raised event using listener?

EventEmitter.js


2.Callback.js show how to use callback funtion using SetTimeOut()

3.App.js and Logger.js

it describes how to call logger function exporting log module
and execute global variables like __filename and __directoryname

4.App1.js and LoggerClass

it describes how to call logger class exporting log class 
and generate event from logger class and handle at client die


5.Export entire object and then at client side use methods and prperties of that object.

movie.js and useMovie.js

6.use system define modules 
osModule.js

7.FieHandling strea.js

8.use express and implement routing

express-1.js

9.use express and implement routing using express routing feature
expressCustomer-2.js

10.FILESYTE,JS IS FOR READING WRITING FILE.

11.ExpressEmployeeMongo.js 
use express/router/mongoose

connect mongoose
and poll to connect if the 

12.HTTPSERVER USE HTTP REQUEST AND IMPLEMENT get/put/post/delete
