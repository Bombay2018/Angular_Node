function SayHello(name){

 console.log("Hello" + name);

}

SayHello("Sudipta")

var message="";
//console.log(global);
console.log(module);

console.log(__dirname);

console.log(__filename);

//mesage undefined

//Every nodejs file is module.


//IMPORT MODULE

var l=require('./logger');
l.log1("Logging done using node js");


//              ./

//             current folder
//            ../ 

//             parent

//            ./sub

//         subfolder

