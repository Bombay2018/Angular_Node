﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RazerTestApp.Model
{
    public class DrawingTemplate
    {
        public int TemplateId { get; set; }
        public string TemplateName { get; set; }
        public bool IsActive { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public List<DrawingTemplateDetails> ControlList { get; set; }
    }

    public class DrawingTemplateDetails
    {
        public int DetailId { get; set; }
        public int TemplateId { get; set; }
        public string ControlType { get; set; }
        public string ControlId { get; set; }
        public string ControlStyle { get; set; }
        public string ControlClass { get; set; }
        public string ImageName { get; set; }
        public string ControlCoords { get; set; }
        public string Description { get; set; }
    }
}