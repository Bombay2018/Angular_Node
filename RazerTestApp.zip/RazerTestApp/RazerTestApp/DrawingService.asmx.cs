﻿using RazerTestApp.DataAccessLayer;
using RazerTestApp.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Script.Services;
using System.Web.Services;

namespace RazerTestApp
{
    /// <summary>
    /// Summary description for DrawingService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class DrawingService : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat= ResponseFormat.Json, UseHttpGet =false)]
        public bool SaveDrawingDetails(DrawingDetailSaveParameter request)
        {
            List<SqlParameter> ParameterList = new List<SqlParameter>();
            ParameterList.Add(new SqlParameter("Name", request.Name));
            ParameterList.Add(new SqlParameter("Content", request.Content));

            return DataAccessLayer.DatabaseHandler.ExecuteProcedure("SaveDrawingDetails", ParameterList);
        }

        public class DrawingDetailSaveParameter
        {
            public string Name { get; set; }
            public string Content { get; set; }
        }

        public class DrawingDetailGetParameter
        {
            public string Type { get; set; }
            public int ID { get; set; }
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public string GetDrawingDetails(DrawingDetailGetParameter request)
        {
            string result = "";

            List<SqlParameter> ParameterList = new List<SqlParameter>();
            ParameterList.Add(new SqlParameter("Type", request.Type));
            ParameterList.Add(new SqlParameter("ID", request.ID));
            DataSet resultDataSet = DataAccessLayer.DatabaseHandler.GetDataSet("GetDrawingDetails", ParameterList);

            if (request.Type == "RENDER")
            {
                result = resultDataSet.Tables[0].Rows[0].Field<string>("Content");
            }
            if (request.Type == "LIST")
            {
                string options = "<option value='0'>---Select File---</option>";
                foreach (DataRow item in resultDataSet.Tables[0].Rows)
                {
                    options = options + "<option value='"+item.Field<int>("ID")+"'>"+item.Field<string>("Name")+"</option>";
                }
                result = options;
            }
            return result;
        }

        #region Common Functions - Added By Anil
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = true)]
        public string GetDrawingTemplateDDL()
        {
            string result = "";
            List<SqlParameter> ParameterList = new List<SqlParameter>();
            DataSet resultDataSet = DataAccessLayer.DatabaseHandler.GetDataSet("usp_DrawingTemplateDDL_Select", ParameterList);
            string options = "<option value='0'>---Select File---</option>";
            foreach (DataRow item in resultDataSet.Tables[0].Rows)
            {
                options = options + "<option value='" + item.Field<int>("TemplateId") + "'>" + item.Field<string>("TemplateName") + "</option>";
            }
            result = options;
            return result;
        }
        #endregion

        #region Save Toolbars - Added By Anil
        public class DrawingToolbarParameter
        {
            public int ToolbarId { get; set; }
            public string ToolbarContent { get; set; }
        }
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public bool SaveDrawingToolbars(DrawingToolbarParameter request)
        {
            List<SqlParameter> ParameterList = new List<SqlParameter>();
            ParameterList.Add(new SqlParameter("ToolbarId", request.ToolbarId));
            ParameterList.Add(new SqlParameter("ToolbarContent", request.ToolbarContent));

            return DataAccessLayer.DatabaseHandler.ExecuteProcedure("usp_Toolbars_SaveUpdate", ParameterList);
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public DrawingToolbarParameter GetDrawingToolbarDetails(DrawingToolbarParameter request)
        {
            DrawingToolbarParameter result = new DrawingToolbarParameter();

            List<SqlParameter> ParameterList = new List<SqlParameter>();            
            ParameterList.Add(new SqlParameter("ToolbarId", request.ToolbarId));
            DataSet resultDataSet = DataAccessLayer.DatabaseHandler.GetDataSet("usp_Toolbars_Select", ParameterList);
            if(resultDataSet.Tables.Count>0)
            {
                if (resultDataSet.Tables[0].Rows.Count > 0)
                {
                    result.ToolbarId = resultDataSet.Tables[0].Rows[0].Field<int>("ToolbarId");
                    result.ToolbarContent = resultDataSet.Tables[0].Rows[0].Field<string>("ToolbarContent");
                }
            }

            return result;
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public string UploadImage()
        {            
            string strMsg = string.Empty;
            if (HttpContext.Current.Request.Files.Count > 0)
            {
                HttpFileCollection files = HttpContext.Current.Request.Files;
                for (int i = 0; i < files.Count; i++)
                {
                    HttpPostedFile file = files[i];
                    string fname = HttpContext.Current.Server.MapPath("~/Images/Toolbars/" + file.FileName);
                    if(!File.Exists(fname))
                    {
                        file.SaveAs(fname);
                        strMsg = "File Uploaded Successfully!";
                    }
                    else
                    {
                        strMsg = "0";
                    }
                }               
                
            }
            return strMsg;
        }
        #endregion


        #region Save Drawing Template - Added By Anil
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public int SaveDrawingTemplate(DrawingTemplate request)
        {            
            string xmlDoc = string.Empty;
            if(request!=null)
            {
                xmlDoc = CommonFunction.GetXMLFromObject(request);
            }
            if(!string.IsNullOrEmpty(xmlDoc))
            {
                List<SqlParameter> ParameterList = new List<SqlParameter>();
                ParameterList.Add(new SqlParameter("xmlDoc", xmlDoc));                
                request.TemplateId =(int)DataAccessLayer.DatabaseHandler.ExecuteScalar("usp_DrawingTemplate_SaveUpdate", ParameterList);                
            }
            return request.TemplateId;
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public DrawingTemplate GetDrawingTemplate(DrawingTemplate request)
        {           
            DrawingTemplate loResult = new DrawingTemplate();
            List<SqlParameter> ParameterList = new List<SqlParameter>();
            ParameterList.Add(new SqlParameter("TemplateId", request.TemplateId));          
            DataSet resultDataSet = DataAccessLayer.DatabaseHandler.GetDataSet("usp_DrawingTemplate_Select", ParameterList);
            List<DrawingTemplateDetails> dtTempDet = new List<DrawingTemplateDetails>();
            if (resultDataSet.Tables[0].Rows[0]["TemplateId"] != null)
            {
                loResult.TemplateId = (int)resultDataSet.Tables[0].Rows[0]["TemplateId"];
            }
            if(resultDataSet.Tables[0].Rows[0]["TemplateName"] !=null)
            {
                loResult.TemplateName = Convert.ToString(resultDataSet.Tables[0].Rows[0]["TemplateName"]);
            }            

            var convertedList = (from rw in resultDataSet.Tables[1].AsEnumerable()
                                 select new DrawingTemplateDetails()
                                 {
                                     DetailId = Convert.ToInt32(rw["DetailId"]),
                                    // TemplateId = Convert.ToInt32(rw["TemplateId"]),
                                     ControlType = Convert.ToString(rw["ControlType"]),
                                     ControlId = Convert.ToString(rw["ControlId"]),
                                     ImageName = Convert.ToString(rw["ImageName"]),
                                     ControlStyle = Convert.ToString(rw["ControlStyle"]),
                                     ControlClass = Convert.ToString(rw["ControlClass"]),
                                     ControlCoords = Convert.ToString(rw["ControlCoords"]),
                                     Description = Convert.ToString(rw["Description"])                                     
                                 }).ToList();

            loResult.ControlList = convertedList;

            return loResult;

        }
        #endregion
    }
}
