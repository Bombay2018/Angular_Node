﻿class AltText {
    constructor(title,description){ 
        this.Title=title;
        this.Descrition=description;
    }
}

class Position {
    constructor(horizontal,veritical,horizontalFrom,veriticalFrom){
        this.Horizontal=horizontal;
        this.Veritical=veritical;
        this.HorizontalFrom=horizontalFrom;
        this.VeriticalFrom=veriticalFrom;
    }
}

class Size {
    constructor(height,width,scaleHeight,scaleWidth,rotation){
        this.Height = height;
        this.Width = width;
        this.ScaleHeight = scaleHeight;
        this.ScaleWidth = scaleWidth;
        this.Rotation = rotation;
    }
}

class TextBox {
    constructor(verticalAlignment, textDirection, leftMargin, rightMargin, topMargin, bottomMargin, wrapTextInShape, allowToOverflow, resizeShapeToFitText) {
        this.VerticalAlignment = verticalAlignment;
        this.TextDirection = textDirection;
        this.LeftMargin = leftMargin;
        this.RightMargin = rightMargin;
        this.TopMargin = topMargin;
        this.BottomMargin = bottomMargin;
        this.WrapTextInShape = wrapTextInShape;
        this.AllowToOverflow = allowToOverflow;
        this.ResizeShapeToFitText = resizeShapeToFitText;
    }
}

class LineStyle{
    constructor(width,compoundType,dashType,joinType,beginArrowType,beginArrowSize,endArrowType,endArrowSize){
        this.Width;
        this.CompundType;
        this.DashType;
        this.JoinType;
        this.BeginArrowType;
        this.BeingArrowSize;
        this.EndArrowType;
        this.EndArrowSize;
        this.color;       
    }
}

class AdditionalProperties{

    constructor(isSendToBack, isSendToForoward, connectorType, isGrouped,groupName) {
        this.IsSendToBack = isSendToBack;
        this.IsSendToForoward = isSendToForoward;
        this.ConnectorType = connectorType;
        this.IsGrouped = isGrouped;
        this.groupName = groupName;
    }  

}

class Point {
    constructor(x, y,x1,y1,x2,y2,x3,y3) {
        this.x = x;
        this.y = y;
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        this.x3 = x3;
        this.y3 = y3;
    }
}

class Shape extends Point {
    constructor(shapeType,x, y, x1, y1, x2, y2, x3, y3) {
        super(x, y, x1, y1,x2,y2,x3,y3);
        this.ShapeType = shapeType;
        this.AltText;
        this.Position;
        this.Size;
        this.TextBox;
        this.LineStyle;        
        this.AddtionalProperties;       
        
        //appliable for lines only
        this.ConnectorType;
    }

    getShapeType() {
        return this.ShapeType;
    }
    getCoordinates()
    {
        return 'x:' + this.x + ', y:' + this.y;
    }
    getAltText() {
        return 'Title:' + this.AltText.Title + ', Description:' + this.AltText.Descrition;
    }
}
