﻿using System.Web;
using System.Web.Services;
using System.Web.Script.Serialization;

namespace RazerTestApp
{
    /// <summary>
    /// Summary description for WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {
        [WebMethod(EnableSession = true)]
        public void HelloWorld()
        {

            Session["ValidSession"] = "1";
            var sessionObject = Session["ValidSession"];
            HttpContext.Current.Response.ContentType = "application/json";
            HttpContext.Current.Response.Charset = "utf-8";
            JavaScriptSerializer serialize = new JavaScriptSerializer();
            HttpContext.Current.Response.Write((serialize.Serialize(Session["ValidSession"].ToString())));
            HttpContext.Current.Response.Flush();
            HttpContext.Current.Response.End();
            //return Session["ValidSession"].ToString();
        }


        [WebMethod(EnableSession = true)]
        public void CheckSession()
        {
            var sessionObject = Session["ValidSession"];
            if (sessionObject != null)
            {
                sessionObject = "1";
            }
            else
            {
                sessionObject = "0";
            }
            HttpContext.Current.Response.ContentType = "application/json";
            HttpContext.Current.Response.Charset = "utf-8";
            JavaScriptSerializer serialize = new JavaScriptSerializer();
            HttpContext.Current.Response.Write((serialize.Serialize(sessionObject)));
            HttpContext.Current.Response.Flush();
            HttpContext.Current.Response.End();
        }
    }
}
