﻿//Presume this to be a db which will be loaded and save in database using Ajax whenever it is changed
var Db = [];
var Mode = "Moving";
var serviceBaseUrl = 'http://localhost:2140';

$(document).ready(function ()
{
    LoadDrawingTemplateDropdown();
    GetDrawingToolbar();
    BindEventWithToolbar();
    BindButtonEvents();

    $("#dvContainer").click(function (e) {
        if ($(e.target).is("img"))
        {           
            return;
        }
        else {            
            $.each($(".selected"), function () { 
                $(this).resizable("destroy");
            });
            $('.selected').removeClass('selected');
            $("#hdnSelectedImage").val("");
        }
    });

    //Disabled right click
    /*
    $("#dvContainer").on("contextmenu", function () {
        return false;
    });

    $("#dvContainer").bind("contextmenu", function (e) {
        e.preventDefault();
        console.log(e.pageX + "," + e.pageY);
        $("#dvContextMenu").css("left", e.pageX);
        $("#dvContextMenu").css("top", e.pageY);
        // $("#cntnr").hide(100);        
        $("#dvContextMenu").fadeIn(200, startFocusOut());
    });   

    $("#items > li").click(function () {
        //alert($(this).text());
        if($(this).text()=="Copy")
        {
            alert($(".selected").attr("id"));
            $("#dvContextMenu").hide();
            $("#dvContainer").off("click");
        }
       // $("img").text("You have selected " + $(this).text());
    });

    */

    MakeToolbarDroppable();
});

function MakeToolbarDroppable()
{
    //Counter
    counter = 0;
    //Make element draggable
    $("#dvToolbarContolSet img").draggable({
        helper: 'clone',
        containment: 'dvContainer',
        //When first dragged
        stop: function (ev, ui) {
            var pos = $(ui.helper).offset();
            objName = "#clonediv" + counter
            $(objName).css({
                "left": pos.left,
                "top": pos.top
            });
         //   $(objName).removeClass("drag");
            //When an existiung object is dragged
            $(objName).draggable({
                containment: 'parent',
                stop: function (ev, ui) {
                    var pos = $(ui.helper).offset();
                    console.log($(this).attr("id"));
                    console.log(pos.left)
                    console.log(pos.top)
                }
            });
        }
    });
    //Make element droppable
    $("#dvContainer").droppable({
        drop: function (ev, ui) {
            if (ui.helper.attr('id').search(/drag[0-9]/) != -1) {
                counter++;
                var element = $(ui.draggable).clone();
                element.addClass("tempclass");
                $(this).append(element);
                $(".tempclass").attr("id", "clonediv" + counter);
                $("#clonediv" + counter).removeClass("tempclass");
                //Get the dynamically item id
                draggedNumber = ui.helper.attr('id').search(/drag([0-9])/)
                itemDragged = "dragged" + RegExp.$1
                console.log(itemDragged)
                $("#clonediv" + counter).addClass(itemDragged);
            }
        }
    });
}

function startFocusOut() {
    $("#dvContainer").on("click", function () {
        $("#dvContextMenu").hide();
        $("#dvContainer").off("click");
    });
}
function BindEventWithToolbar()
{
    $(".Toolbar img").click(function (e) {
        var This = this;
        var ButtonId = $(This).attr("Id");
        var imgSRC = $(This).attr("src");

        $(".Toolbar img").removeClass("Selected");
        $(This).addClass("Selected");

        /*
        if (ButtonId == "btnMove")
        {
            //Mode = "Moving";
            var Index = Db.length;
            Db.push({ Id: "Shape" + Index, ImageSrc: "/Images/Image0.jpg", Top: 100, Left: 100, Height: 100, Width: 100 })
            AttachDragHandler(Index);
        }
        else if (ButtonId == "btnShape1")
        {
            var Index = Db.length;
            Db.push({ Id: "Shape" + Index, ImageSrc: "/Images/Image1.png", Top: 100, Left: 100, Height: 100, Width: 100 })
            AttachDragHandler(Index);
        }
        else if (ButtonId == "btnShape2")
        {
            var Index = Db.length;
            Db.push({ Id: "Shape" + Index, ImageSrc: "/Images/Image2.png", Top: 100, Left: 100, Height: 100, Width: 100 })
            AttachDragHandler(Index);
        }
        else {
            // Common for All icons
            var Index = Db.length;
            Db.push({ Id: "Shape" + Index, ImageSrc: imgSRC, Top: 100, Left: 100, Height: 100, Width: 100 })
            AttachDragHandler(Index);
        }*/

        // Common for All icons       
        var Index = Db.length;
        Db.push({ Id: "Shape" + Index, src: imgSRC, Top: 0, Left: 0, Height: 100, Width: 100,className:'', detailId: 0, title: '', description: '' });
        AttachDragHandler(Index);

        setTimeout(function () {
            $(".Toolbar img").removeClass("Selected");
            $("#btnMove").addClass("Selected");
        }, 200);

        ClearSelection();
        
        //Apply Tooltips
        //  ApplyToolTips();

      //  ApplyCoordinates();

        //Apply Image Selection
     //   ApplyImageSelection();

       

      //  $(document).tooltip();


    });
}
function ClearSelection()
{
    $('.selected').removeClass('selected');
    $("#hdnSelectedImage").val("");    
}
function BindButtonEvents()
{
    $("#btnClearSelection").on("click", function (event) {
        $('.selected').resizable("disable");
        $('.selected').removeClass('selected');
        $("#hdnSelectedImage").val("");

    });

    $("#btnDeleteSelection").on("click", function () {
        $('.selected').remove();
        $("#hdnSelectedImage").val("");
    });

    // Append Toolbar Element
    $("#btnAddImage").on("click", function () {
        UploadToolbarIcon();
    });
    $("#btnSaveToolbar").on("click", function () {
        SaveDrawingToolbars()
    });

    $("#btnSaveImage").on("click", function () {
        SaveTemplate();
    });
        //ajax close


    $("#btnOpenImage").on("click", function () {

        var selectedOption = $("#ddlFiles option:selected").val();
        if (selectedOption === 0 || selectedOption === "0") {
            alert("Kindly select saved file.");
        }
        else {
            $("#txtFileName").val($("#ddlFiles option:selected").text());

            BindTemplate();


        }//closing else

    });

    $("#btnNewImage").on("click", function () {
        $("#dvContainer").html("");
        $("#txtFileName").val("");
    });

    $("#btnAddText").click(function () {
        var This = this;
        var ButtonId = $(This).attr("Id");

        var txtBoxCount = $("p[id^=txtBox]").length;
        var Id = 'txtBox_' + txtBoxCount;

        $("#dvContainer").append("<p id='" + Id + "' class='DraggableShape'  ondblclick='editableBox(this.id);' onChange='editableBoxChange(this.id);' onblur='uneditableBox(this.id);' style='top:50px;left:50px;height:50px;width:200px;'></p>");
     //   $("#dvContainer").append("<div id='" + Id + "' class='DraggableShape textarea' contentEditable='true' data-text='Enter text here' style='top:5px;left:5px;'></div>");

        $("#" + Id).draggable(
        {
            containment: '#dvContainer',
            opacity: 0.35,
            cursor: "move",
            stop: function (Event, Ui) {
                var DragObjectIndex = $(Ui.helper[0]).attr('id').substr(5);
                Id.Top = Ui.offset.top;
                Id.Left = Ui.offset.left;
            }
        });

        //$(this).resizable();

        //document.getElementById(Id).innerHTML = "TextBox";
        //document.getElementById(Id).contentEditable = true;
        //$("#" + Id).focus();
        //$("#" + Id).select();

    });

    $("#popup_div").on('click', '#btnSave', function () {
        $("#popup_div").dialog("close");
        var objId = $("#hdnObjId").val();
        $("#spn_" + objId).html($("#txtDesc").val());
        $("#txtDesc").val("");
        $("#hdnObjId").val("");
    });
}

function AttachDragHandler(Index)
{    
    //$("body").append("<img id='" + Db[Index].Id + "' class='DraggableShape' src='" + Db[Index].ImageSrc + "' style='top: " + Db[Index].Top + "px; 'left: " + Db[Index].Left + "px; height: " + Db[Index].Height + "px; width: " + Db[Index].Width + "px'/><div class='coords'></div>");
    // $("#dvContainer").append("<img id='" + Db[Index].Id + "' class='DraggableShape' src='" + Db[Index].ImageSrc + "' style='top: " + Db[Index].Top + "px;left: " + Db[Index].Left + "px; height: " + Db[Index].Height + "px; width: " + Db[Index].Width + "px'/>");
    $("#dvContainer").append("<img id='" + Db[Index].Id + "' src='" + Db[Index].src + "' class='DraggableShape rotate' style='top: " + Db[Index].Top + "px;left: " + Db[Index].Left + "px; height: " + Db[Index].Height + "px; width: " + Db[Index].Width + "px' title='" + Db[Index].title + "' detailId='" + Db[Index].detailId + "'/> <span id='spn_" + Db[Index].Id + "' class='tag'>" + Db[Index].description + "</span>");
     
    
    
    $("#" + Db[Index].Id).draggable(
    {
        containment: '#dvContainer',
        opacity: 0.35,
        cursor: "move",
        //over: function (Event, Ui)
        //{
        //    $(this).addClass('DragableHover');
        //},
        //start: function (Event, Ui)
        //{
        //},
        stop: function (Event, Ui)
        {
            var DragObjectIndex = $(Ui.helper[0]).attr('id').substr(5);

            Db[DragObjectIndex].Top = Ui.offset.top;
            Db[DragObjectIndex].Left = Ui.offset.left;
            //ToDo: Save Db object to Database            
        },
        //out: function (Event, Ui)
        //{
        //    $(this).removeClass('DragableHover');
        //},
    });
    RenderControlDesc();
    BindControlEvents();

}

function ApplyCoordinates()
{
    $.each($("body .DraggableShape"), function () {
       
        $image = $(this);
        imgPos = [
            $image.offset().left,
            $image.offset().top,
            $image.offset().left + $image.outerWidth(),
            $image.offset().top + $image.outerHeight()
        ];

        $image.mousemove(function (e) {            
            $(this).attr("title",(e.pageX - imgPos[0]) + ', ' + (e.pageY - imgPos[1]));
        });

       
      
    });
}
function ApplyToolTips()
{
    $.each($("body div.DraggableShape"), function () {
        $(this).addClass("tooltip");

        $(this).append("<span class='tooltiptext'>" + $(this).attr("id") + "</span>");
        //alert($(this).html());
    });
}
function ApplyImageSelection()
{    
    $('.DraggableShape').click(function () {
        $('.selected').resizable("destroy");
        $('.selected').removeClass('selected');
        $(this).addClass('selected');        
        $(this).resizable();
        
        
       // $(this).selectable();
        $("#hdnSelectedImage").val($(this).attr("Id"));
    });

    $("#dvContainer img").dblclick(function () {
        var objId = $(this).attr("id");
        $("#popup_div").dialog();
        $("#hdnObjId").val(objId);
        $("#txtDesc").val($("#spn_" + objId).html());
    });

    
}
function zoomin() {

    //    var myImg = document.getElementById(objId);
    var objId = $("#hdnSelectedImage").val();    
    if (objId != undefined || objId != null) {
        var myImg = document.getElementById(objId);
        var currWidth = myImg.clientWidth;
        if (currWidth == 500) {
            alert("Maximum zoom-in level reached.");
        } else {
            myImg.style.width = (currWidth + 50) + "px";
        }
        $(".ui-wrapper").css('height', myImg.style.height);
        $(".ui-wrapper").css('width', myImg.style.width);
    }
}
function zoomout() {
    var objId = $("#hdnSelectedImage").val();   
    if (objId != undefined || objId != null) {
        var myImg = document.getElementById(objId);
        var currWidth = myImg.clientWidth;
        if (currWidth == 50) {
            alert("Maximum zoom-out level reached.");
        } else {
            myImg.style.width = (currWidth - 50) + "px";
        }

        $(".ui-wrapper").css('height', myImg.style.height);
        $(".ui-wrapper").css('width', myImg.style.width);
    }
}
var angle = 0;
function rotateleft()
{   
    angle -= 10;
    $(".selected").rotate(angle);
}
function rotateright() {
    angle += 10;
    $(".selected").rotate(angle);
}

function editableBox(Id) {
    document.getElementById(Id).contentEditable = true;
    $("#" + Id).focus();
}
function uneditableBox(Id) {
    document.getElementById(Id).contentEditable = false;
}
function editableBoxChange(Id) {
    //alert(Id);
    var contentLen = $('#' + Id).val().length;
    $('#' + Id).css('width', contentLen * 5 + 'px!important');
}


function LoadToolbars() {
    var dir = "images/";
    var fileextension = ".png";
    $.ajax({
        //This will retrieve the contents of the folder if the folder is configured as 'browsable'
        url: dir,
        success: function (data) {
            //Lsit all png file names in the page
            $(data).find("a:contains(" + fileextension + ")").each(function () {
                var filename = this.href.replace(window.location.host, "").replace("http:///", "");
                $("body").append($("<img src=" + dir + filename + "></img>"));
            });
        }
    });
}
function UploadToolbarIcon() {

    var fileUpload = $("#fileUpload").get(0);
    var files = fileUpload.files;

    var formData = new FormData();
    for (var i = 0; i < files.length; i++) {
        formData.append(files[i].name, files[i]);
    }

    if (files.length <= 0) {
        alert('Please select atleast one icon!');
        return false;
    }
    else {
        $.ajax({
            url: serviceBaseUrl + "/DrawingService.asmx/UploadImage",
            type: 'POST',
            data: formData,
            processData: false,  // tell jQuery not to process the data
            contentType: false,  // tell jQuery not to set contentType           
            success: function (data) {                
                if (data.children[0].innerHTML == "0") {
                    alert('Toolbar Icon already exists!');
                    return false;
                }
                else {
                  //  alert(data.children[0].innerHTML);
                    for (var i = 0; i < files.length; i++) {
                        $("#dvToolbarContolSet").append("<img id='toolbar" + i + "' src='/Images/Toolbars/" + files[i].name + "' />");
                    }
                    BindEventWithToolbar();
                }
            }
        });
    }
}

function SaveDrawingToolbars()
{
    var contentObject = $("#dvToolbarContolSet").html();
    if (contentObject.length < 1) {
        alert("Empty Toolbar cannot saved.");
        return false;
    }

    var dataObject = {
        ToolbarId: $("#hdnToolbarId").val(),
        ToolbarContent: contentObject
    };

    $.ajax({
        cache: false,
        url: serviceBaseUrl + "/DrawingService.asmx/SaveDrawingToolbars",
        datatype: "json",
        data: JSON.stringify({ request: dataObject }),
        contentType: "application/json; charset=utf-8",
        type: "POST",
        success: function (data, textStatus, jqXHR) {           
            if (data.d) {
                alert("Record Saved Successfully.");
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log('Error:=>' + errorThrown);
        }
    });
}

function GetDrawingToolbar() {
    var parameter={
        ToolbarId: $("#hdnToolbarId").val(),
        ToolbarContent:''
    };
    $.ajax({
        cache: false,
        url: serviceBaseUrl + "/DrawingService.asmx/GetDrawingToolbarDetails",
        datatype: "json",
        data: JSON.stringify({ request: parameter }),
        contentType: "application/json; charset=utf-8",
        type: "POST",
        async: false,
        success: function (data, textStatus, jqXHR) {            
            if (data.d.ToolbarContent != null && data.d.ToolbarContent != "") {
                $("#dvToolbarContolSet").html("");
                $("#dvToolbarContolSet").html(data.d.ToolbarContent);
                $("#hdnToolbarId").val(data.d.ToolbarId);
            }
            
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log('Error:=>' + errorThrown);
        }
    });
}

function LoadDrawingTemplateDropdown()
{
    $.ajax({
        cache: false,
        url: serviceBaseUrl + "/DrawingService.asmx/GetDrawingTemplateDDL",
        datatype: "json",       
        contentType: "application/json; charset=utf-8",
        type: "GET",
        async: false,
        success: function (data, textStatus, jqXHR) {           
            $("#ddlFiles").html("");
            $("#ddlFiles").html(data.d);
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log('Error:=>' + errorThrown);
        }
    });
}
function BindTemplate() {   
    var templateId = $("#ddlFiles option:selected").val();

    var parameter = {
        TemplateId: templateId
    };

    $.ajax({
        cache: false,
        url: serviceBaseUrl + "/DrawingService.asmx/GetDrawingTemplate",
        datatype: "json",
        data: JSON.stringify({ request: parameter }),
        contentType: "application/json; charset=utf-8",
        type: "POST",
        async: false,
        success: function (data, textStatus, jqXHR) {
            //   debugger;
            if (data.d.TemplateId > 0) {
                $("#hdnTemplateId").val(data.d.TemplateId);
                $("#dvContainer").html("");
                //$("#dvContainer").html(data.d);
                LoadTemplateDetails(data.d.ControlList);
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log('Error:=>' + errorThrown);
        }
    });
}

function LoadTemplateDetails(jsonResult) {
    var imgsrcPath = "/Images/Toolbars/";
    var strHTML = "";
    $.each(jsonResult, function (a, b) {

        if (b.ControlType == "img") {
            strHTML += "<img id='" + b.ControlId + "' src='" + imgsrcPath + b.ImageName + "' class='" + b.ControlClass + "' style='" + b.ControlStyle + "' title='" + b.ControlCoords + "' detailId='" + b.DetailId + "'/>";
            strHTML += "<span id='spn_" + b.ControlId + "' class='tag'>" + b.Description + "</span>";
        }
    });

    $("#dvContainer").html(strHTML);
    RenderControlDesc();
    BindControlEvents();

}

function RenderControlDesc() {
    $.each($(".tag"), function () {

        var ctrId = $(this).attr("id");
        var ids = ctrId.split('_');
        var obj = $("#" + ids[1]);
        $(this).offset($(obj).offset());

        //Make object draggable
        $(obj).draggable({
            // containment: '#dvContainer',
            opacity: 0.35,
            cursor: "move",
            stop: function (Event, Ui) {
                var obj = $(this);
                $("#spn_" + $(this).attr("id")).offset(obj.offset());
            }
        });

    });
}
function BindControlEvents() {
       
    $("#dvContainer img").on("click", function () {       
        $('.selected').removeClass('selected');
        $(this).addClass('selected');
        $("#hdnSelectedImage").val($(this).attr("Id"));

        $(this).resizable({
            // containment: '#dvContainer',
            opacity: 0.35,
            cursor: "move",
            //autoHide: true,
            stop: function (Event, Ui) {
                var obj = $(this).find("img");
                $("#spn_" + $(obj).attr("id")).offset(obj.offset());
               // $(obj).resizable("destroy");
               // $('.selected').removeClass('selected');
            }
        });
    });
    
    $("#dvContainer img").dblclick(function () {        
        var objId = $(this).attr("id");
        $("#popup_div").dialog();
        $("#hdnObjId").val(objId);
        $("#txtDesc").val($("#spn_" + objId).html());
    });
   
}

function SaveTemplate() {
    //var serviceBaseUrl = 'http://localhost:2135';
    var imgsrcPath = "/Images/Toolbars/";
    var jsonResult = [];
    $.each($("#dvContainer img"), function () {
        jsonResult.push({ DetailId: $(this).attr("DetailId"), ControlType: 'img', ControlId: $(this).attr("id"), ControlClass: $(this).attr("class"), ControlStyle: $(this).attr("style"), ImageName: $(this).attr("src").replace(imgsrcPath, ""), ControlCoords: $(this).attr("title"), Description: $("#spn_" + $(this).attr("id")).html() });

    });
   
    if (jsonResult.length == 0) {
        alert('No Image Found.');
        return false;
    }
    else if ($("#txtFileName").val().length < 3) {
        alert("Please enter drawing template name.");
        $("#txtFileName").focus();
        return false;
    }
    else {
        var parameter = { TemplateId: $("#hdnTemplateId").val(), TemplateName: $("#txtFileName").val(), IsActive: true, ControlList: jsonResult };
        $.ajax({
            cache: false,
            url: serviceBaseUrl + "/DrawingService.asmx/SaveDrawingTemplate",
            datatype: "json",
            data: JSON.stringify({ request: parameter }),
            contentType: "application/json; charset=utf-8",
            type: "POST",
            async: false,
            success: function (data, textStatus, jqXHR) {
                if (data.d > 0) {
                    $("#hdnTemplateId").val(0);
                    alert("Record Saved Successfully.");
                    $("#txtFileName").val("");
                    $("#dvContainer").html("");
                    LoadDrawingTemplateDropdown();
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log('Error:=>' + errorThrown);
            }
        });
    }
}