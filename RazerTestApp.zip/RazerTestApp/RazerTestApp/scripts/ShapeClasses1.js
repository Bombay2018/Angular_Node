﻿function Size(height,width,rotation)
{
    this.Height = height;
    this.Width = width;
    this.Rotation = rotation;
}

function Position(horizontalPosition, horizontalPositionFrom, verticalPosition, verticalPositionFrom) {
    this.HorizontalPosition = horizontalPosition;
    this.HorizontalPositionFrom = horizontalPositionFrom;
    this.VerticalPosition = verticalPosition;
    this.VerticalPositionFrom = verticalPositionFrom;
}

function TextBox(verticalAlignment,textDirection,leftMargin,rightMargin,topMargin,bottomMargin,wrapTextInShape,allowToOverflow,resizeShapeToFitText) {
    this.VerticalAlignment = verticalAlignment;
    this.TextDirection = textDirection;
    this.LeftMargin = leftMargin;
    this.RightMargin = rightMargin;
    this.TopMargin = topMargin;
    this.BottomMargin = bottomMargin;
    this.WrapTextInShape = wrapTextInShape;
    this.AllowToOverflow = allowToOverflow;
    this.ResizeShapeToFitText = resizeShapeToFitText;
}

function AltText(title,description) {
    this.Title = title;
    this.Description = description;
}

function Arrange(bringToFront,sendToBack,align) {
    this.BringToFront = bringToFront;
    this.SendToBack = sendToBack;
    this.Align = align;
}

function Line(x1, y1, x2, y2,color,transparency,width) {
    this.X1 = x1;
    this.Y1 = y1;
    this.X2 = x2;
    this.Y2 = y2;
    this.Color = color;
    this.Transparency = transparency;
    this.Width = width;
    

}
Line.prototype = {
    getStartPoint: function () {
        return 'X1: ' + this.X1 + ', Y1:' + this.Y1;
    },
    getColor: function () {
        return this.Color;
    }
}


function Polygon()
{
    this.Picture;
    this.Color;
    this.Height;
    this.Width;
    this.Rotation;
    this.ScaleHeight;
    this.ScaleWidth;
}
Polygon.prototype = {
    getColor: function () {
        return this.Color;
    }
}

function Circle() {
    this.Picture;
    this.Color;
    this.Height;
    this.Width;
    this.Rotation;
    this.ScaleHeight;
    this.ScaleWidth;
}
Polygon.prototype = {
    getColor: function () {
        return this.Color;
    }
}

