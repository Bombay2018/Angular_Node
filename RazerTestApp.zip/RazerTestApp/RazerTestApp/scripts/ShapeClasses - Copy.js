﻿class Shape {
    constructor(color, weight, lineType) {
        this.Color = color;
        this.Weight = weight;
        this.LineType = lineType;
    }

    getColor() {
        return 'Color:' + this.Color;
    }
}

class Size {
    constructor(height,width,scaleHeight,scaleWidth) {
        this.Height = height;
        this.Width = width;
        this.ScaleHeight = scaleHeight;
        this.ScaleWidth = scaleWidth;
    }
}

class Line extends Shape {
    
    constructor(x1, y1, x2, y2, weight, color, lineType) {
        super(color, weight, lineType);
        this.X1 = x1;
        this.Y1 = y2;
        this.X2 = x2;
        this.Y2 = y2;
    }

    getStartPoint() {
        return 'x1: ' + this.X1 + ' y1: ' + this.Y1;
    }
    getColor()
    {
        return super.getColor();
    }
}

class Rectangle extends Shape(Size) {
    constructor(height, width, color, weight, lineType) {
        super(color, weight, lineType);
        
        //this.Height = height;
        //this.Width = width;
    }

    // Getter
    get area() {
        return this.calcArea();
    }
    // Method
    calcArea() {
        return this.Height * this.Width;
    }
}





/*

class AltText {
    this.Title;
    this.Descrition;
    }


class Position {
    this.Horizontal;
    this.Veritical;
    this.HorizontalFrom;
    this.VeriticalFrom;
    }


class Size {
    this.Height;
    this.Width;
    this.ScaleHeight;
    this.ScaleWidth;
    }


class LineStyle{
    this.Width;
    this.CompundType;
    this.DashType;
    this.JoinType;
    this.BeginArrowType;
    this.BeingArrowSize;
    this.EndArrowType;
    this.EndArrowSize;
    this.color;       
    }

class AddtionalProperties{
    This.IsSendToBack;
    This.IsSendToForoward;
    this.ConnectorType;
    this.IsGrouped;

    }



class Point {
    constructor(x, y,x1,y1) {
        this.xStart = x;
        this.yStart = y;
        this.xEnd = x1;
        this.yEnd = y1;
    }
}


class Line extends Point {
    constructor(x, y,x1,y1, color) {
        super(x, y,x1,y1);
        this.LineStyle = color;
    }    
}
*/