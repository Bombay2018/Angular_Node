﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace RazerTestApp.DataAccessLayer
{
    public class DatabaseHandler
    {
        #region "Constructor"
        public DatabaseHandler()
        {

        }
        #endregion

        #region "Properties"

        internal static string ConnectionString()
        {

            return ConfigurationManager.AppSettings["DrawingConnectionString"];

        }

        #endregion

        #region "Public Methods"

        public static SqlDataReader GetReader(string StoredProcedureName)
        {
            SqlDataReader Reader;
            SqlConnection Conn;


            Conn = new SqlConnection(ConnectionString());
            Conn.Open();

            SqlCommand CommandObject = new SqlCommand(StoredProcedureName, Conn);
            CommandObject.CommandType = CommandType.StoredProcedure;
            Reader = CommandObject.ExecuteReader(CommandBehavior.CloseConnection);

            CommandObject.Dispose();

            return Reader;
        }

        public static DataSet GetDataSet(string StoredProcedureName, List<SqlParameter> ParameterList)
        {
            DataSet DataSetObject = new DataSet();
            using (SqlConnection Conn = new SqlConnection(ConnectionString()))
            {
                using (SqlCommand CommandObject = new SqlCommand(StoredProcedureName, Conn))
                {
                    CommandObject.CommandType = CommandType.StoredProcedure;
                    CommandObject.Parameters.AddRange(ParameterList.ToArray());

                    SqlDataAdapter Adapter = new SqlDataAdapter(CommandObject);
                    Adapter.Fill(DataSetObject);
                }
            }

            return DataSetObject;
        }

        public static bool ExecuteNonQuery(string Query, List<SqlParameter> ParameterList)
        {
            bool Result = false;
            using (SqlConnection Conn = new SqlConnection(ConnectionString()))
            {
                if (Conn.State != System.Data.ConnectionState.Open)
                {
                    Conn.Open();
                }

                using (SqlCommand CommandObject = new SqlCommand(Query, Conn))
                {
                    CommandObject.Parameters.AddRange(ParameterList.ToArray());
                    int Count = CommandObject.ExecuteNonQuery();
                    Result = Count > 0;
                }
            }
            return Result;
        }

        public static bool ExecuteProcedure(string StoredProcedureName, List<SqlParameter> ParameterList)
        {
            bool Result = false;
            using (SqlConnection Conn = new SqlConnection(ConnectionString()))
            {
                if (Conn.State != System.Data.ConnectionState.Open)
                {
                    Conn.Open();
                }

                using (SqlCommand CommandObject = new SqlCommand(StoredProcedureName, Conn))
                {
                    CommandObject.CommandType = CommandType.StoredProcedure;
                    CommandObject.Parameters.AddRange(ParameterList.ToArray());
                    int count =(int)CommandObject.ExecuteNonQuery();
                    Result = count > 0;
                }
            }
            return Result;
        }

        public static object ExecuteScalar(string StoredProcedureName, List<SqlParameter> ParameterList)
        {
            object liResult;
            using (SqlConnection Conn = new SqlConnection(ConnectionString()))
            {
                if (Conn.State != System.Data.ConnectionState.Open)
                {
                    Conn.Open();
                }

                using (SqlCommand CommandObject = new SqlCommand(StoredProcedureName, Conn))
                {
                    CommandObject.CommandType = CommandType.StoredProcedure;
                    CommandObject.Parameters.AddRange(ParameterList.ToArray());
                    liResult = (object)CommandObject.ExecuteScalar();                   
                }
            }
            return liResult;
        }

        #endregion

    }
}