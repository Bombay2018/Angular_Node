﻿using Microsoft.Owin.Security.DataHandler.Encoder;
using SecurityApi.Entities;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Web;

namespace SecurityApi.Models
{
    public static class AudiencesStore
    {
        public static ConcurrentDictionary<string, Audience> AudiencesList = new ConcurrentDictionary<string, Audience>();

        static AudiencesStore()
        {
            AudiencesList.TryAdd("7f109d3f011d4783ae097e9e0c7208f4",
                                new Audience
                                {
                                    ClientId = "7f109d3f011d4783ae097e9e0c7208f4",
                                    Base64Secret = "V1Wq0nNaYcytY9rTGSI4mSIZLCzxfF2nTfcQ3iYU1NI",
                                    Api = "http://localhost:57222/",
                                    Name = "ABC",                                    
                                });

            AudiencesList.TryAdd("099153c2625149bc8ecb3e85e03f0022",
                                new Audience
                                {
                                    ClientId = "099153c2625149bc8ecb3e85e03f0022",
                                    Base64Secret = "IxrAjDoa2FqElO7IhrSrUJELhUckePEPVpaePlS_Xaw",
                                    Name = "ResourceServer.Api"
                                });
        }


        public static void AudienceList()
        {

            AudiencesList.TryAdd("7f109d3f011d4783ae097e9e0c7208f4",
                                new Audience
                                {
                                    ClientId = "7f109d3f011d4783ae097e9e0c7208f4",
                                    Base64Secret = "V1Wq0nNaYcytY9rTGSI4mSIZLCzxfF2nTfcQ3iYU1NI",
                                    Name = "ChenoaPOC"
                                });

            AudiencesList.TryAdd("099153c2625149bc8ecb3e85e03f0022",
                                new Audience
                                {
                                    ClientId = "099153c2625149bc8ecb3e85e03f0022",
                                    Base64Secret = "IxrAjDoa2FqElO7IhrSrUJELhUckePEPVpaePlS_Xaw",
                                    Name = "ResourceServer.Api"
                                });
        }

        public static Audience AddAudience(string name)
        {
            var clientId = Guid.NewGuid().ToString("N");

            var key = new byte[32];
            RNGCryptoServiceProvider.Create().GetBytes(key);
            var base64Secret = TextEncodings.Base64Url.Encode(key);

            Audience newAudience = new Audience { ClientId = clientId, Base64Secret = base64Secret, Name = name };
            AudiencesList.TryAdd(clientId, newAudience);
            return newAudience;
        }

        public static Audience FindAudience(string clientId)
        {
            Audience audience = null;
            if (AudiencesList.TryGetValue(clientId, out audience))
            {
                return audience;
            }
            return null;
        }
    }
}