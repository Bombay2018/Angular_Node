﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Xml.Serialization;
using Freight.Application.Enums;

namespace BusinessObjects
{
    public class CustomerFreightRateRequestDto
    {
        public int CustomerId { get; set; }
        public int OrderId { get; set; }
        public string ProviderId { get; set; }
    }
  
}
