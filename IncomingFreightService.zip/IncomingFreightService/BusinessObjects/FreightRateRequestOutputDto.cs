﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObjects
{

    public class FreightRateRequestOutputDto {

        public int RateType { get; set; }
        public decimal TotalBillingWeightValue { get; set; }
        public decimal TotalBillingWeightUnits { get; set; }
        public decimal TotalBaseChargeAmount { get; set; }
        public decimal TotalBaseChargeCurrency { get; set; }
        public decimal TotalFreightDiscountsAmount { get; set; }
        public string TotalFreightDiscountsCurrency { get; set; }
        public decimal TotalSurchargesAmount { get; set; }
        public string TotalSurchargesCurrency { get; set; }
        public decimal TotalNetChargeAmount { get; set; }
        public string TotalNetChargeCurrency { get; set; }
        public bool IsActive { get; set; }         
      
      
    }

    public class FreightRateRequestOutputDto2
    {

        public int RateType { get; set; }
        public decimal TotalBillingWeightValue { get; set; }
        public decimal TotalBillingWeightUnits { get; set; }
        public decimal TotalBaseChargeAmount { get; set; }
        public decimal TotalBaseChargeCurrency { get; set; }
        public decimal TotalFreightDiscountsAmount { get; set; }
        public string TotalFreightDiscountsCurrency { get; set; }
        public decimal TotalSurchargesAmount { get; set; }
        public string TotalSurchargesCurrency { get; set; }
        public decimal TotalNetChargeAmount { get; set; }
        public string TotalNetChargeCurrency { get; set; }
        public bool IsActive { get; set; }


    }

    //public class FreightRateRequestOutputDto
    //{
    //    public int ServiceType { get; set; }
    //    public int PackagingType { get; set; }
    //    public RatedShipmentDetails RatedShipmentDetails { get; set; }
    //}

    //public class RatedShipmentDetails
    //{
    //    public TotalBillingWeight TotalBillingWeight { get; set; }
    //    public AmountDetails TotalBaseCharge { get; set; }
    //    public AmountDetails TotalFreightDiscounts { get; set; }
    //    public AmountDetails TotalSurcharges { get; set; }
    //    public Surcharge Surcharges { get; set; }
    //}

    //public class TotalBillingWeight
    //{
    //    public int Value { get; set; }
    //    public int Units { get; set; }
    //}

    //public class Surcharge
    //{
    //    public string SurchargeType { get; set; }
    //    public AmountDetails Amount { get; set; }
    //}

    //public class FreightRateDetail
    //{
    //    public int QuoteNumber { get; set; }
    //    public BaseCharge BaseCharges { get; set; }
    //}

    //public class BaseCharge
    //{
    //    public string Description { get; set; }
    //    public Weight Weight { get; set; }
    //    public ChargeRate ChargeRate { get; set; }
    //    public ExtendedAmount ExtendedAmount { get; set; }
    //}

    //public class ExtendedAmount
    //{
    //    public int Amount { get; set; }
    //    public int Currency { get; set; }
    //}

    //public class ChargeRate
    //{
    //    public int Amount { get; set; }
    //    public int Currency { get; set; }
    //}

    //public class RateReplyDetail
    //{
    //    public bool DeliveryTimestampSpecified { get; set; }
    //    public DateTime DeliveryTimestamp { get; set; }
    //    public bool TransitTimeSpecified { get; set; }
    //    public DateTime TransitTime { get; set; }
    //    public string ServiceType { get; set; }
    //}

    //public class RateReply
    //{
    //    public Notification Notification { get; set; }
    //}

    //public class Notification
    //{
    //    public bool SeveritySpecified { get; set; }
    //    public int Severity { get; set; }
    //    public int Code { get; set; }
    //    public string Message { get; set; }
    //    public string Source { get; set; }
    //}
}
