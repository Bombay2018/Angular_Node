﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Freight.Application.Enums
{
    public enum Providers
    {
        Provider1,
        Provider2
    }
}
