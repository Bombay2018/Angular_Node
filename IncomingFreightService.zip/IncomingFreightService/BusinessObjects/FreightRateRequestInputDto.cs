﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Xml.Serialization;
using Freight.Application.Enums;

namespace BusinessObjects
{   
    public class FreightRateRequestInputDto
    {
        public DateTime ShipTimeStamp { get; set; }
        public bool ShipTimeStampSpecified { get; set; }
        public DropOffType DropOffType { get; set; }
        public ServiceType ServiceType { get; set; }
        public bool ServiceTypeSpecified { get; set; }
        public PackagingType PackagingType { get; set; }
        public bool PackagingTypeSpecified { get; set; }
        public int PackageCount { get; set; }
        public Shipper Shipper { get; set; }
        public Recipient Recipient { get; set; }
        public ShippingChargesPayment ShippingChargesPayment { get; set; }
        public FreightShipmentDetail FreightShipmentDetail { get; set; }
        public WebAuthenticationDetail WebAuthentication { get; set; }
    }

    public class WebAuthenticationDetail
    {

        public UserCredential UserCredential { get; set; }
    }


    public class UserCredential
    {
        public string Key { get; set; }
        public string Password { get; set; }        
    }

    public class Shipper
    {
        public Address ShipperAddress { get; set; }
    }

    public class Recipient
    {
        public Address RecipientAddress { get; set; }
    }

    public class ShippingChargesPayment
    {
        public PaymentType PaymentType { get; set; }
        public bool PaymentTypeSpecified { get; set; }
        public Payor PayorDetails { get; set; }
    }

    public class Payor
    {
        public ResponsibleParty ResponsibleParty { get; set; }
    }

    public class ResponsibleParty
    {
        public string AccountNumber { get; set; }
        public Contact Contact { get; set; }
        public Address Address { get; set; }
    }

    public class FreightShipmentDetail
    {
        public string FedExFreightAccountNumber { get; set; }
        public FreightShipmentRoleType Role { get; set; }
        public bool RoleSpecified { get; set; }
        public int TotalHandlingUnits { get; set; }
        public FedExFreightBillingContactAndAddress FedExFreightBillingContactAndAddress { get; set; }
        public DeclaredValuePerUnit DeclaredValuePerUnit { get; set; }
        public LiabilityCoverageDetail LiabilityCoverageDetail { get; set; }
        public ShipmentDimensions ShipmentDimensions { get; set; }
        public LineItems LineItems { get; set; }
    }

    public class FedExFreightBillingContactAndAddress
    {
        public Contact Contact { get; set; }
        public Address Address { get; set; }
    }

    public class Contact
    {
        public string PersonName { get; set; }
        public string CompanyName { get; set; }
        public string PhoneNumber { get; set; }
    }

    public class Address
    {
        public string StreetLines { get; set; }
        public string City { get; set; }
        public string StateOrProvinceCode { get; set; }
        public string PostalCode { get; set; }
        public string CountryCode { get; set; }
    }

    public class DeclaredValuePerUnit : AmountDetails
    {

    }

    public class LiabilityCoverageDetail : AmountDetails
    {
        public LiabilityCoverageType CoverageType { get; set; }
        public bool CoverageTypeSpecified { get; set; }
    }

    public class AmountDetails
    {
        public string Currency { get; set; }
        public decimal Amount { get; set; }
        public bool AmountSpecified { get; set; }
    }

    public class ShipmentDimensions
    {
        public Dimension ShipmentDimension { get; set; }
    }

    public class LineItems
    {
        public FreightClassType FreightClass { get; set; }
        public bool FreightClassSpecified { get; set; }
        public PhysicalPackagingType Packaging { get; set; }
        public bool PackagingSpecified { get; set; }
        public string Description { get; set; }
        public Weight Weight { get; set; }
        public Dimension Dimension { get; set; }
        public Volume Volume { get; set; }
    }

    public class Weight
    {
        public WeightUnits Units { get; set; }
        public bool UnitsSpecified { get; set; }
        public string Value { get; set; }
        public bool ValueSpecified { get; set; }
    }

    public class Dimension
    {
        public int Length { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
        public LinearUnits Units { get; set; }
        public bool UnitsSpecified { get; set; }
    }

    public class Volume
    {
        public VolumeUnits Units { get; set; }
        public bool UnitsSpecified { get; set; }
        public string Value { get; set; }
        public bool ValueSpecified { get; set; }
    }
}
