﻿using BusinessObjects;
using DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public class ContactDetails : IContactDetails
    {
        static List<Phone> Contacts;

        static ContactDetails()
        {
            //if (Contacts.Count() == 0)
            //{
                Contacts = new List<Phone>();
                Contacts.Add(new Phone { UserId = 1000, AlternateMobileNumber = 12312312, PhoneNumber = 214321423 });
                Contacts.Add(new Phone { UserId = 1001, AlternateMobileNumber = 12312312, PhoneNumber = 214321423 });
                Contacts.Add(new Phone { UserId = 1002, AlternateMobileNumber = 12312312, PhoneNumber = 214321423 });
                Contacts.Add(new Phone { UserId = 1002, AlternateMobileNumber = 12312312, PhoneNumber = 214321423 });
            //}
        }

        public List<Phone> GetPhone()
        {           
            return Contacts.ToList();
        }

        public Phone GetContactWithId(int Id)
        {
            Contacts = BusinessModule.Contacts;
            return Contacts.Where(i => i.UserId == Id).FirstOrDefault();
        }

        public List<Phone> AddUpdateContact(Phone phone)
        {
            if (phone.UserId == 0)
            {
                int seq = Contacts.Count() + 1;
                phone.UserId =  int.Parse("100" + seq.ToString());

                Contacts.Add(phone);
            }
            else
            {
                var item = Contacts.FirstOrDefault(w => w.UserId == phone.UserId);

                item.PhoneNumber = phone.PhoneNumber;
                item.AlternateMobileNumber = phone.AlternateMobileNumber;
            }

            return Contacts;
        }

        public List<Phone> DeletePhone(int Id)
        {           
            Contacts.RemoveAll(r => r.UserId == Id);
            return Contacts;
        }
    }
}
