﻿using BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public interface IContactDetails
    {
        Phone GetContactWithId(int Id);
        List<Phone> AddUpdateContact(Phone phone);
        List<Phone> DeletePhone(int Id);
        List<Phone> GetPhone();
    }
}
