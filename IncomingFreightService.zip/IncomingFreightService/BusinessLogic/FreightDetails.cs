﻿using BusinessObjects;
using BusinessLogic.Factory;
using DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Freight.Application.Enums;
using Newtonsoft.Json;

namespace BusinessLogic
{
    public class FreightDetails : IFreightDetails
    {

        IUnitOfWork unitOfWork;
        private Repository<Order> OrdersRepository;
        private Repository<DataAccess.Shipper> ShippersRepository;
        private Repository<DataAccess.ShipperResponse> ShippersResponseRepository;
        private Repository<Customer> CustomerRepository;
        private Repository<Provider> providerRepository;
        private Repository<OrderDetailLineItem> OrderDetailLineItemRepository;

        public FreightDetails(IUnitOfWork _unitOfWork)
        {
            unitOfWork = _unitOfWork;
            OrdersRepository = unitOfWork.Repository<Order>();
            ShippersRepository = unitOfWork.Repository<DataAccess.Shipper>();
            CustomerRepository = unitOfWork.Repository<Customer>();
            OrderDetailLineItemRepository = unitOfWork.Repository<OrderDetailLineItem>();
            providerRepository = unitOfWork.Repository<Provider>();
            ShippersResponseRepository = unitOfWork.Repository<DataAccess.ShipperResponse>();
        }

        public FreightDetails()
        {

        }

        public FreightRateRequestInputDto GetFreightRequestParams(CustomerFreightRateRequestDto request)
        {
            var result = from o in OrdersRepository.AsQueryable()
                         join s in ShippersRepository.AsQueryable() on o.ShipmentId equals s.ShipmentId
                         join c in CustomerRepository.AsQueryable() on o.CustomerId equals c.CustomerId
                         join od in OrderDetailLineItemRepository.AsQueryable() on o.OrderId equals od.OrderId
                         where o.OrderId.Equals(request.OrderId)
                         select new FreightRateRequestInputDto
                         {
                             ShipTimeStamp = s.ShipTimestamp.Value,
                             ShipTimeStampSpecified = s.ShipTimestampSpecified.Value,
                             DropOffType = DropOffType.DROP_BOX, //(DropOffType)Enum.Parse(typeof(DropOffType), s.DropoffType.ToString()),
                             ServiceType = ServiceType.STANDARD_OVERNIGHT, //(ServiceType)Enum.Parse(typeof(ServiceType), s.ServiceType.ToString()),
                             ServiceTypeSpecified = s.ServiceTypeSpecified.Value,
                             PackagingType = PackagingType.FEDEX_TUBE, //(PackagingType)Enum.Parse(typeof(PackagingType), s.PackagingType.ToString()),
                             PackagingTypeSpecified = s.PackagingTypeSpecified.Value,
                             Shipper = new BusinessObjects.Shipper
                             {
                                 ShipperAddress = new Address
                                 {
                                     City = s.City,
                                     CountryCode = s.CountryCode,
                                     PostalCode = s.PostalCode,
                                     StateOrProvinceCode = s.StateOrProvinceCode,
                                     StreetLines = s.StreetLines,
                                 },

                             },
                             Recipient = new Recipient
                             {
                                 RecipientAddress = new Address
                                 {
                                     City = c.City,
                                     CountryCode = c.CountryCode,
                                     PostalCode = c.PostalCode,
                                     StateOrProvinceCode = c.StateOrProvinceCode,
                                     StreetLines = c.StreetLines,
                                 },
                             },
                             ShippingChargesPayment = new ShippingChargesPayment
                             {
                                 PaymentType = PaymentType.SENDER, //(PaymentType)Enum.Parse(typeof(PaymentType), o.PaymentType.ToString()),
                                 PaymentTypeSpecified = o.PaymentTypeSpecified.Value,
                                 PayorDetails = new Payor
                                 {
                                     ResponsibleParty = new ResponsibleParty
                                     {
                                         AccountNumber = s.ResponsiblePartyAccountNumber,
                                         Contact = new Contact
                                         {
                                             CompanyName = "",
                                             PersonName = "",
                                             PhoneNumber = s.ResponsiblePartyContactPhone,
                                         },
                                         Address = new Address
                                         {
                                             City = s.ResponsiblePartyCity,
                                             CountryCode = s.ResponsiblePartyCity,
                                             PostalCode = s.ResponsiblePartyStateOrProvinceCode,
                                             StateOrProvinceCode = s.ResponsiblePartyStateOrProvinceCode,
                                             StreetLines = s.ResponsiblePartyStreetLines,
                                         },
                                     }

                                 },

                             },
                             FreightShipmentDetail = new FreightShipmentDetail
                             {
                                 DeclaredValuePerUnit = new DeclaredValuePerUnit
                                 {
                                     Amount = 0.0M,
                                     AmountSpecified = false,
                                     Currency = "USD",
                                 },
                                 FedExFreightAccountNumber = od.FedExFreightAccountNumber,
                                 LiabilityCoverageDetail = new LiabilityCoverageDetail
                                 {
                                     Amount = od.CoverageAmount.Value,
                                     AmountSpecified = od.CoverageAmountSpecified.Value,
                                     CoverageType = LiabilityCoverageType.NEW, //(LiabilityCoverageType)Enum.Parse(typeof(LiabilityCoverageType), s.ServiceType.ToString()),
                                     CoverageTypeSpecified = od.CoverageTypeSpecified.Value,
                                     Currency = od.CoverageCurrency
                                 },
                                 LineItems = new LineItems()
                                 {
                                     Description = od.Description,
                                     Dimension = new Dimension
                                     {
                                         Height = od.DimensionsHeight.Value,
                                         Length = od.DimensionsLength.Value,
                                         Units = LinearUnits.IN, // (LinearUnits)Enum.Parse(typeof(LinearUnits), od.DimensionsUnit.ToString()),
                                         UnitsSpecified = od.DimensionsUnitsSpecified.Value,
                                         Width = od.DimensionsWidth.Value
                                     }
                                 }
                                 ,
                                 Role = FreightShipmentRoleType.SHIPPER, //(FreightShipmentRoleType)Enum.Parse(typeof(FreightShipmentRoleType), od.Role),
                                 RoleSpecified = od.RoleSpecified.Value,
                                 ShipmentDimensions = new ShipmentDimensions
                                 {
                                     ShipmentDimension = new Dimension
                                     {
                                         Height = od.DimensionsHeight.Value,
                                         Length = od.DimensionsLength.Value,
                                         Units = LinearUnits.IN, //(LinearUnits)Enum.Parse(typeof(LinearUnits), od.DimensionsUnit.ToString()),
                                         UnitsSpecified = od.DimensionsUnitsSpecified.Value,
                                         Width = od.DimensionsWidth.Value,
                                     }
                                 },
                                 TotalHandlingUnits = od.TotalHandlingUnits.Value,
                                 FedExFreightBillingContactAndAddress = new FedExFreightBillingContactAndAddress
                                 {
                                     Address = new Address
                                     {
                                         City = "",
                                         CountryCode = "",
                                         PostalCode = "",
                                         StateOrProvinceCode = "",
                                         StreetLines = "",
                                     },
                                     Contact = new Contact
                                     {
                                         CompanyName = "",
                                         PersonName = "",
                                         PhoneNumber = "",
                                     },
                                 },
                             },
                             WebAuthentication = new WebAuthenticationDetail
                             {
                                 UserCredential = new UserCredential
                                 {
                                     Key = c.UserName,
                                     Password = c.Password
                                 }
                             },
                             PackageCount = od.GroupPackageCount.Value,
                         };

            return result.FirstOrDefault();
        }


        public object GetFreightProviders()
        {
            var result = from provider in providerRepository.AsQueryable()
                         select new
                         {
                             provider.Id,
                             provider.Provider1

                         };


            return result;
        }

        public object GetCustomers()
        {
            var result = from customer in CustomerRepository.AsQueryable()
                         select new
                         {
                             customer.CustomerId,
                             customer.CustomerName
                         };

            return result;
        }

        public object GetOrders(int cutomerId)
        {
            var result = from o in OrdersRepository.AsQueryable()
                         join c in CustomerRepository.AsQueryable() on o.CustomerId equals c.CustomerId
                         join P in providerRepository.AsQueryable() on c.ProviderId equals P.Id
                         where o.CustomerId.Equals(cutomerId)
                         select new
                         {
                             o.OrderId,
                             P.Id
                         };

            return result;
        }


        public object GetFreightRateRequest_old(string request, string providers)
        {
            List<Task<string>> runningTasks = new List<Task<string>>();

            if (providers.Contains("1"))
            {
                FreightProvider1Service.IService1 prvd1 = new FreightProvider1Service.Service1Client();
                Task<string> task = Task.Run(() => prvd1.GetFreightRate(request));
                runningTasks.Add(task);
            }

            if (providers.Contains("2"))
            {
                FreightRateProvider2Service.IRateService2 prvd2 = new FreightRateProvider2Service.RateService2Client();
                Task<string> task2 = Task.Run(() => prvd2.GetFreightRate(request));
                runningTasks.Add(task2);
            }

            // default service given by Ingram
            if (providers.Contains("0"))
            {
                FreightRateProvider2Service.IRateService2 prvd2 = new FreightRateProvider2Service.RateService2Client();
                Task<string> task2 = Task.Run(() => prvd2.GetFreightRate(request));
                runningTasks.Add(task2);
            }

            Task.WaitAll(runningTasks.ToArray());

            //Dictionary<decimal, object> rateList = new Dictionary<decimal, object>();
            //foreach (var item in runningTasks)
            //{
            //    Dictionary<decimal, object> rateList = new Dictionary<decimal, object>();
            //    FreightRateRequestOutputDto rateResponse1 = JsonConvert.DeserializeObject<FreightRateRequestOutputDto>(task.Result);
            //}

            Dictionary<decimal, object> rateList = new Dictionary<decimal, object>();

            if (runningTasks.Count == 2)
            {


                FreightRateRequestOutputDto rateResponse1 = JsonConvert.DeserializeObject<FreightRateRequestOutputDto>(runningTasks[0].Result);
                FreightRateRequestOutputDto2 rateResponse2 = JsonConvert.DeserializeObject<FreightRateRequestOutputDto2>(runningTasks[1].Result);
                rateList.Add(rateResponse1.TotalBillingWeightValue, runningTasks[0].Result);
                rateList.Add(rateResponse2.TotalBillingWeightValue, runningTasks[1].Result);
            }

            if (runningTasks.Count == 1 && providers.Contains("0"))
            {
                FreightRateRequestOutputDto2 rateResponse2 = JsonConvert.DeserializeObject<FreightRateRequestOutputDto2>(runningTasks[0].Result);
                rateList.Add(rateResponse2.TotalBillingWeightValue, runningTasks[0].Result);
            }

            if (runningTasks.Count == 1 && !providers.Contains("0"))
            {
                if (providers.Contains("1"))
                {
                    FreightRateRequestOutputDto rateResponse1 = JsonConvert.DeserializeObject<FreightRateRequestOutputDto>(runningTasks[0].Result);
                    rateList.Add(rateResponse1.TotalBillingWeightValue, runningTasks[0].Result);
                }
                if (providers.Contains("2"))
                {
                    FreightRateRequestOutputDto2 rateResponse2 = JsonConvert.DeserializeObject<FreightRateRequestOutputDto2>(runningTasks[0].Result);
                    rateList.Add(rateResponse2.TotalBillingWeightValue, runningTasks[0].Result);
                }
            }

            if (rateList.Count > 0)

                return rateList.OrderBy(x => x.Key).FirstOrDefault().Value;
            else
                return rateList.Values;
            //if(rateResponse1.TotalBillingWeightValue<rateResponse2.TotalBillingWeightValue)
            //    return task.Result;
            //else
            //    return task2.Result;

            //Compare Rate of services


            //Retunr lowest rate Json

            //return task.Result;
            //return res;


        }

        #region Created by Dasharath on 12-01-2018

        public object GetFreightRateRequest(string request, string providers)
        {
            Dictionary<decimal, string> rateList = new Dictionary<decimal, string>();

            if (string.IsNullOrEmpty(providers) || providers == "0")
            {
                providers = "1";// set default provider, it can be also configurable
            }

            var tasks = new List<Task>();
            foreach (string provider in providers.Split(','))
            {
                IProviderFreightRate iFreightRate = ProviderFreightRateFactory.CreateFreightRateFactory(provider);

                tasks.Add(Task.Factory.StartNew(() => iFreightRate.GetFreightRate(request)));
            }

            Task.WaitAll(tasks.ToArray());

            foreach (var task in tasks)
            {
                var result = (task as Task<FreightRateResult>).Result;
                if (!rateList.ContainsKey(result.Rate))
                {
                    rateList.Add(result.Rate, result.RateJson);
                }
            }

            return rateList.OrderBy(x => x.Key).FirstOrDefault().Value;
        }

        #endregion Created by Dasharath on 12-01-2018

        public object GetFreightRateResponse(string request)
        {

            // FreightRateEntities context = new FreightRateEntities();


            var result = new FreightRateRequestOutputDto
            {
                TotalBillingWeightValue = 20.0M,
                TotalBillingWeightUnits = 20,
                TotalBaseChargeAmount = 30,
                TotalBaseChargeCurrency = 50,
                TotalFreightDiscountsAmount = 60,
                TotalFreightDiscountsCurrency = "USD",
                TotalSurchargesAmount = 80,
                TotalSurchargesCurrency = "INR"
            };

            return result;


            //TotalBillingWeightValue = response.TotalBillingWeightValue.Value,
            //                 TotalBillingWeightUnits = response.TotalBillingWeightUnits.Value,
            //                 TotalBaseChargeAmount = response.TotalBaseChargeAmount.Value,
            //                 TotalBaseChargeCurrency = Convert.ToDecimal(response.TotalBaseChargeCurrency),
            //                 TotalFreightDiscountsAmount = response.TotalFreightDiscountsAmount.Value,
            //                 TotalFreightDiscountsCurrency = response.TotalFreightDiscountsCurrency,
            //                 TotalSurchargesAmount = response.TotalSurchargesAmount.Value,
            //                 TotalSurchargesCurrency = response.TotalSurchargesCurrency

        }

        public object GetFreightRateResponse2(string request)
        {

            // FreightRateEntities context = new FreightRateEntities();

            var result = new FreightRateRequestOutputDto2
            {
                TotalBillingWeightValue = 30.0M,
                TotalBillingWeightUnits = 25,
                TotalBaseChargeAmount = 35,
                TotalBaseChargeCurrency = 55,
                TotalFreightDiscountsAmount = 65,
                TotalFreightDiscountsCurrency = "USD",
                TotalSurchargesAmount = 85,
                TotalSurchargesCurrency = "INR"
            };

            return result;
        }

    }
}
