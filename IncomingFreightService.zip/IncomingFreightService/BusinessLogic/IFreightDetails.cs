﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessObjects;

namespace BusinessLogic
{
    public interface IFreightDetails
    {
        FreightRateRequestInputDto GetFreightRequestParams(CustomerFreightRateRequestDto request);
        object GetCustomers();
        object GetOrders(int customerId);
        object GetFreightProviders();
        //object GetFreightRate(string request);
        object GetFreightRateRequest(string request, string provider);
    }
}
