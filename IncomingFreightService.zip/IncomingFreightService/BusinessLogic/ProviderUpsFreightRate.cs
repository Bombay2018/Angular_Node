﻿using BusinessObjects;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public class ProviderUpsFreightRate: IProviderFreightRate
    {
        public FreightRateResult GetFreightRate(string request)
        {
            //ToDo: Need to chnge service
            FreightProvider1Service.IService1 provider = new FreightProvider1Service.Service1Client();

            string jsonResponse = provider.GetFreightRate(request);

            FreightRateRequestOutputDto rateResponse = JsonConvert.DeserializeObject<FreightRateRequestOutputDto>(jsonResponse);

            FreightRateResult rateResult = new FreightRateResult();
            rateResult.Rate = rateResponse.TotalBillingWeightValue;
            rateResult.RateJson = jsonResponse;

            return rateResult;
        }
    }
}
