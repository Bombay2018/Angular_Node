﻿using BusinessObjects;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public class ProviderDhlFreightRate : IProviderFreightRate
    {
        FreightRateResult IProviderFreightRate.GetFreightRate(string request)
        {
            FreightRateProvider2Service.IRateService2 provider = new FreightRateProvider2Service.RateService2Client();

            string jsonResponse = provider.GetFreightRate(request);


            FreightRateRequestOutputDto rateResponse = JsonConvert.DeserializeObject<FreightRateRequestOutputDto>(jsonResponse);

            FreightRateResult rateResult = new FreightRateResult();
            rateResult.Rate = rateResponse.TotalBillingWeightValue;
            rateResult.RateJson = jsonResponse;

            return rateResult;
        }
    }
}
