﻿using BusinessObjects;
using DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public class UserManagement : IUserManagement
    {
        public static List<LoginDetailInput> LoginDetails;

        static UserManagement()
        {           

            //if (LoginDetails.Count() == 0) {
                LoginDetails = new List<LoginDetailInput>();
                LoginDetails.Add(new LoginDetailInput { FullName = "Jagdish sahu", Password = "test!123", Role = "Tester", Username = "ABC", UserId = 1000 });
                LoginDetails.Add(new LoginDetailInput { FullName = "Bharat Taksalia", Password = "test!1234", Role = "Developer", Username = "DEF", UserId = 1001 });
                LoginDetails.Add(new LoginDetailInput { FullName = "Ram shyam", Password = "test!12345", Role = "Manager", Username = "GHI", UserId = 1002 });
                LoginDetails.Add(new LoginDetailInput { FullName = "gaga baba", Password = "test!123456", Role = "Analyst", Username = "JKL", UserId = 1003 });
            //}
        }

        public  LoginDetailOutput PostLogin(LoginDetailInput input)
        {
            LoginDetailOutput output = new LoginDetailOutput();            

            foreach (var item in LoginDetails.Where(w => w.Username == input.Username && w.Password == input.Password))
            {
                output.Username = item.Username;
                output.Role = item.Role;
                output.FullName = item.FullName;
            }
            return output;
        }

      
        //public List<Restaurant> GetRestaurant()
        //{
        //    var restaurants = new List<Restaurant>();

        //    var dt = new DataTable();
        //    var dbUtility = new DBUtility();
        //    dt = dbUtility.GetDataTable(SpRestaurants, "Name");
        //    if (dt != null & dt.Rows.Count > 0)
        //    {
        //        foreach (DataRow dr in dt.Rows)
        //        {
        //            restaurants.Add(new Restaurant { ID = Convert.ToInt32(dr["ID"]), Name = Convert.ToString(dr["Name"]) });
        //        }
        //    }
        //    return restaurants;
        //}

        //public string UnSubscribeUser(string emailId)
        //{
        //    DBUtility dbUtility = new DBUtility();
        //    List<SqlParameter> dbParams = new List<SqlParameter>();
        //    dbParams.Add(new SqlParameter("@email", emailId));

        //    SqlParameter outPutParameter = new SqlParameter();
        //    outPutParameter.ParameterName = "@OutputMessage";
        //    outPutParameter.SqlDbType = System.Data.SqlDbType.NVarChar;
        //    outPutParameter.Size = 100;
        //    outPutParameter.Direction = System.Data.ParameterDirection.Output;

        //    return dbUtility.ExecuteNonQuery("uspUpdateSubscriber", dbParams, outPutParameter);
        //}


        //public Stream ExportData(string years, bool withCustomizable)
        //{
        //    try
        //    {
        //        using (EventLog log = new EventLog() { Source = "Application" })
        //        {
        //            SqlParameter[] lstParams = { new SqlParameter("@years", years), new SqlParameter("@withCustomizable", withCustomizable) };
        //            var _objDUT = new DBUtility();
        //            DataSet ds = _objDUT.GetDataSet("uspAnnualExport_CSV", lstParams);
        //            StringBuilder sb = new StringBuilder();
        //            StringBuilder sbColumn = new StringBuilder();
        //            sb.Append(ds.Tables[0].Rows[0][0]);
        //            sb.AppendLine();
        //            for (int i = 0; i < ds.Tables[1].Rows.Count; i++)
        //            {
        //                sb.Append(ds.Tables[1].Rows[i][0].ToString());
        //                sb.AppendLine();
        //            }
        //            var retval = Common.ToStream(sb);
        //            return retval;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return null;
        //    }
        //}


    }
}
