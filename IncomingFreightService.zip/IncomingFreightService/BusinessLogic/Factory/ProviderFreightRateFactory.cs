﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Factory
{
    public class ProviderFreightRateFactory
    {
        public static IProviderFreightRate CreateFreightRateFactory(string provider)
        {
            switch (provider)
            {
                case "1":
                    return new ProviderFedexFreightRate();
                case "2":
                    return new ProviderUpsFreightRate();
                case "3":
                    return new ProviderDhlFreightRate();
                default:
                    //Need to decide default provider
                    return new ProviderFedexFreightRate(); //
            }
        }
    }
}
