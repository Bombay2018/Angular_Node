﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using Newtonsoft.Json;
using BusinessObjects;
using BusinessLogic;

namespace Provider2Service
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "RateService2" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select RateService2.svc or RateService2.svc.cs at the Solution Explorer and start debugging.
    public class RateService2 : IRateService2
    {
        public string GetFreightRate(string request)
        {
            //var objectRequest = JsonConvert.DeserializeObject<FreightRateRequestInputDto>(request);

            FreightDetails frt = new FreightDetails();
            return JsonConvert.SerializeObject(frt.GetFreightRateResponse2(request));

        }
    }
}
