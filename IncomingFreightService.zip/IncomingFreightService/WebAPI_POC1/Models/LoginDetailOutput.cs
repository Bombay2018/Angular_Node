﻿namespace WebAPI_POC1.Models
{
    public class LoginDetailOutput
    {
        public string Username { get; set; }
        public string Role { get; set; }
        public string FullName { get; set; }
    }
}