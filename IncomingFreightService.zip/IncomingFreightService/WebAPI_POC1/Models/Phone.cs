﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebAPI_POC1.Models
{
    public class Phone
    {
        [Required]
        public int UserId { get; set; }

        [Required]
        public int PhoneNumber { get; set; }

        public int AlternateMobileNumber { get; set; }
    }
}