﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebAPI_POC1.Models
{
    public class Address
    {
        [Required]
        public int UserId { get; set; }
        
        public string PermanentAddress { get; set; }

        public string CurrentAddress { get; set; }
    }
}