﻿namespace WebAPI_POC1.Models
{
    public class LoginDetailInput
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
        public string FullName { get; set; }        
    }
}