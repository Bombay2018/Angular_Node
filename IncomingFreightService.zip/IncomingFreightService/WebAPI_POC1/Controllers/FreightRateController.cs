﻿using BusinessLogic;
using BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Newtonsoft.Json;

namespace WebAPI_POC1.Controllers
{
    [RoutePrefix("api")]
    public class FreightRateController : ApiController
    {
        public IFreightDetails FreightDetails;

        public FreightRateController(IFreightDetails _FreightDetails)
        {
            this.FreightDetails = _FreightDetails;
        }

        [HttpPost]
        [Route("FreightRateRequest")]
        public HttpResponseMessage Get(CustomerFreightRateRequestDto request)
        {
            var freightRateRequestInputDto = FreightDetails.GetFreightRequestParams(request);

            //Call Rate WCF API VIA BAL Layer
            var freightResponse=FreightDetails.GetFreightRateRequest(JsonConvert.SerializeObject(freightRateRequestInputDto), request.ProviderId);

            if (freightRateRequestInputDto != null)
                //return Request.CreateResponse(HttpStatusCode.OK, freightRateRequestInputDto);
                  return Request.CreateResponse(HttpStatusCode.OK, freightResponse);
            else
            {
                var response = new HttpResponseMessage(HttpStatusCode.NotFound);
                response.Content = new StringContent("Freight rate request not found");
                throw new HttpResponseException(response);
            }
        }

        [HttpGet]
        [Route("Customer")]
        public HttpResponseMessage GetCustomer()
        {
            var customerList = FreightDetails.GetCustomers(); ;

            if (customerList != null)
                return Request.CreateResponse(HttpStatusCode.OK, customerList);
            else
            {
                var response = new HttpResponseMessage(HttpStatusCode.NotFound);
                response.Content = new StringContent("Freight rate request not found");
                throw new HttpResponseException(response);
            }
        }

        [HttpGet]
        [Route("Providers")]
        public HttpResponseMessage GetProviders()
        {
            var providerList = FreightDetails.GetFreightProviders();

            if (providerList != null)
                return Request.CreateResponse(HttpStatusCode.OK, providerList);
            else
            {
                var response = new HttpResponseMessage(HttpStatusCode.NotFound);
                response.Content = new StringContent("Freight rate request not found");
                throw new HttpResponseException(response);
            }
        }

        [HttpGet]
        [Route("Orders/{customerId}")]
        public HttpResponseMessage GetOrders(int customerId)
        {
            var customerOrders = FreightDetails.GetOrders(customerId);

            if (customerOrders != null)
                return Request.CreateResponse(HttpStatusCode.OK, customerOrders);
            else
            {
                var response = new HttpResponseMessage(HttpStatusCode.NotFound);
                response.Content = new StringContent("Freight rate request not found");
                throw new HttpResponseException(response);
            }
        }
    }
}
