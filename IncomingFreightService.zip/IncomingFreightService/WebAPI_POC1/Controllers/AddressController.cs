﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPI_POC1.Models;
using WebAPI_POC1.BusinessIntegrator;

namespace WebAPI_POC1.Controllers
{
    [RoutePrefix("api")]
    public class AddressController : ApiController
    {
        [AcceptVerbs("GET")]
        // GET: api/Address/5
        public HttpResponseMessage Get(int id)
        {
            var address = BusinessModule.GetAddressWithId(id);
            if (address != null)
                return Request.CreateResponse(HttpStatusCode.OK, address);
            else
            {
                var response = new HttpResponseMessage(HttpStatusCode.NotFound);
                response.Content = new StringContent("No Address found");
                throw new HttpResponseException(response);
            }
        }

        [AcceptVerbs("POST")]
        // POST: api/Address
        public HttpResponseMessage Post(Address address)
        {
            try
            {
                int id = BusinessModule.PostAddress(address);
                address.UserId = id;
                var response = new HttpResponseMessage { StatusCode = HttpStatusCode.Created };
                response.Headers.Location = new Uri((Request.RequestUri.ToString()) + address.UserId);
                return response;
            }
            catch (Exception e)
            {
                var response = new HttpResponseMessage(HttpStatusCode.Conflict);
                response.Content = new StringContent(e.Message);
                throw new HttpResponseException(response);
            }
        }
        [AcceptVerbs("PUT")]
        // PUT: api/Address/5
        public HttpResponseMessage Put(Address address, string current, string permanent)
        {
            try
            {
                BusinessModule.PutAddress(address, current, permanent);
                // Acceptable status codes are 200/201/204
                var response = new HttpResponseMessage(HttpStatusCode.NoContent);
                response.Headers.Location = new Uri(Request.RequestUri.ToString());
                return response;
            }
            catch (Exception e)
            {
                var response = new HttpResponseMessage(HttpStatusCode.Conflict);
                response.Content = new StringContent(e.Message);
                throw new HttpResponseException(response);
            }
        }
        [AcceptVerbs("DELETE")]
        // DELETE: api/Address/5
        public HttpResponseMessage Delete(int Id)
        {
            BusinessModule.DeleteAddress(Id);
            // Acceptable status codes are 200/202/204
            var response = new HttpResponseMessage(HttpStatusCode.Accepted);
            return response;
        }
    }
}
