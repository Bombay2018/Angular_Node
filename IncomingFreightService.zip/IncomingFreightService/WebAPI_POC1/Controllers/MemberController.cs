﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPI_POC1.Models;
using WebAPI_POC1.BusinessIntegrator;
namespace WebAPI_POC1.Controllers
{
    [RoutePrefix("api")]
    public class MemberController : ApiController
    {
        // GET: api/Member
        public IEnumerable<Member> Get()
        {
            return BusinessModule.GetMembers();
        }

        // GET: api/Member/5
        public HttpResponseMessage Get(int id)
        {
            var member = BusinessModule.GetMemberWithId(id);
            if (member != null)
                return Request.CreateResponse(HttpStatusCode.OK, member);
            else
            {
                var response = new HttpResponseMessage(HttpStatusCode.NotFound);
                response.Content = new StringContent("No Member with Id: " + id + ", was found.");
                throw new HttpResponseException(response);
            }
        }

        // POST: api/Member
        public HttpResponseMessage Post(Member member)
        {
            try
            {
                int id = BusinessModule.PostMember(member);
                member.UserId = id;
                var response = new HttpResponseMessage { StatusCode = HttpStatusCode.Created };
                response.Headers.Location = new Uri((Request.RequestUri.ToString()) + member.UserId);
                return response;
            }
            catch (Exception e)
            {
                var response = new HttpResponseMessage(HttpStatusCode.Conflict);
                response.Content = new StringContent(e.Message);
                throw new HttpResponseException(response);
            }
        }

        // PUT: api/Member/5
        public HttpResponseMessage Put(Member member,string username,string password)
        {
            try
            {
                BusinessModule.PutMember(member,username,password);
                // Acceptable status codes are 200/201/204
                var response = new HttpResponseMessage(HttpStatusCode.NoContent);
                response.Headers.Location = new Uri(Request.RequestUri.ToString());
                return response;
            }
            catch (Exception e)
            {
                var response = new HttpResponseMessage(HttpStatusCode.Conflict);
                response.Content = new StringContent(e.Message);
                throw new HttpResponseException(response);
            }
        }

        // DELETE: api/Address/5
        public HttpResponseMessage Delete(int Id)
        {
            BusinessModule.DeleteMember(Id);
            // Acceptable status codes are 200/202/204
            var response = new HttpResponseMessage(HttpStatusCode.Accepted);
            return response;
        }
    }

}

