﻿using BusinessLogic;
using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPI_POC1.BusinessIntegrator;
using BusinessObjects;
using System.Collections.Generic;
//using WebAPI_POC1.Models;

namespace WebAPI_POC1.Controllers
{
    [RoutePrefix("api")]
    public class PhoneController : ApiController
    {

        public IContactDetails ContactDetails;

        public PhoneController(IContactDetails _ContactDetails)
        {
           this.ContactDetails = _ContactDetails;
        }

        [HttpGet]
        [Route("Contact/{id}")]
        public HttpResponseMessage Get(int id)
        {
           // ContactDetails contactDetails = new ContactDetails();

            var phone = ContactDetails.GetContactWithId(id);
            if (phone != null)
                return Request.CreateResponse(HttpStatusCode.OK, phone);
            else
            {
                var response = new HttpResponseMessage(HttpStatusCode.NotFound);
                response.Content = new StringContent("Phone Number not found");
                throw new HttpResponseException(response);
            }
        }

        [HttpGet]
        [Route("Contact")]
        public HttpResponseMessage GetContact()
        {           

            var phone = ContactDetails.GetPhone();
            if (phone.Count != 0)
                return Request.CreateResponse(HttpStatusCode.OK, phone);
            else
            {
                var response = new HttpResponseMessage(HttpStatusCode.NotFound);
                response.Content = new StringContent("Phone Number not found");
                throw new HttpResponseException(response);
            }
        }

        [HttpPost]
        [Route("AddUpdateContact")]
        public HttpResponseMessage AddUpdateContact(Phone phone)
        {
            try
            {
                ContactDetails contactDetails = new ContactDetails();
                var result = contactDetails.AddUpdateContact(phone);
                return Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception e)
            {
                var response = new HttpResponseMessage(HttpStatusCode.Conflict);
                response.Content = new StringContent(e.Message);
                throw new HttpResponseException(response);
            }
        }

        [HttpPost]
        [Route("DeletePhone/{id}")]
        public HttpResponseMessage DeletePhone(int id)
        {
            try
            {
                ContactDetails contactDetails = new ContactDetails();
                List<Phone> result = contactDetails.DeletePhone(id);
                return Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception e)
            {
                var response = new HttpResponseMessage(HttpStatusCode.Conflict);
                response.Content = new StringContent(e.Message);
                throw new HttpResponseException(response);
            }
        }
    }
}
