﻿using System;
using System.Threading.Tasks;
using System.Web.Http;
using Infrastructure;
using Microsoft.Owin;
using Owin;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.DataHandler.Encoder;
using Microsoft.Owin.Security.Jwt;
using System.Net.Http.Formatting;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

[assembly: OwinStartup(typeof(WebAPI_POC1.Startup))]

namespace WebAPI_POC1
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            HttpConfiguration config = new HttpConfiguration();

            config.DependencyResolver = new UnityResolver(Bootstrapper.Initialise());

            config.MapHttpAttributeRoutes();

            ConfigureOAuth(app);

            app.UseCors(Microsoft.Owin.Cors.CorsOptions.AllowAll);

            config.Formatters.Clear();
            config.Formatters.Add(new JsonMediaTypeFormatter());
            config.Formatters.JsonFormatter.SerializerSettings =
            new JsonSerializerSettings
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver()
            };

            app.UseWebApi(config);

        }


        public void ConfigureOAuth(IAppBuilder app)
        {
            var issuer = "http://localhost:12415/";
            var audience = "7f109d3f011d4783ae097e9e0c7208f4";
            var secret = TextEncodings.Base64Url.Decode("V1Wq0nNaYcytY9rTGSI4mSIZLCzxfF2nTfcQ3iYU1NI");

            // Api controllers with an [Authorize] attribute will be validated with JWT
            app.UseJwtBearerAuthentication(
                new JwtBearerAuthenticationOptions
                {
                    AuthenticationMode = AuthenticationMode.Active,
                    AllowedAudiences = new[] { audience },
                    IssuerSecurityTokenProviders = new IIssuerSecurityTokenProvider[]
                    {
                        new SymmetricKeyIssuerSecurityTokenProvider(issuer, secret)
                    },
                    Provider = new CookieOAuthBearerProvider(".authToken"),
                }
                );



        }
    }
}
