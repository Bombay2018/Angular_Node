﻿using System.Collections.Generic;
using System.Linq;
using WebAPI_POC1.Models;

namespace WebAPI_POC1.BusinessIntegrator
{
    public static class BusinessModule
    {
        private static List<Member> Members;
        private static List<Address> Addresses;
        private static List<Phone> Contacts;
        private static List<LoginDetailInput> LoginDetails;
        static BusinessModule()
        {
            Members = new List<Member>();
            Members.Add(new Member { UserId = 1, UserName = "Ram", Password = "test!123", IsDeleted = false });
            Members.Add(new Member { UserId = 2, UserName = "Sham", Password = "test!1234", IsDeleted = false });
            Members.Add(new Member { UserId = 3, UserName = "Ram", Password = "test!1235", IsDeleted = false });
            Addresses = new List<Address>();
            Addresses.Add(new Address {UserId=1,CurrentAddress="ABC",PermanentAddress="XYZ" });
            Addresses.Add(new Address { UserId = 2, CurrentAddress = "ABC", PermanentAddress = "XYZ" });
            Addresses.Add(new Address { UserId = 3, CurrentAddress = "ABC", PermanentAddress = "XYZ" });
            Contacts = new List<Phone>();
            Contacts.Add(new Phone { UserId = 1000, AlternateMobileNumber = 12312312, PhoneNumber = 214321423 });
            Contacts.Add(new Phone { UserId = 1001, AlternateMobileNumber = 12312312, PhoneNumber = 214321423 });
            Contacts.Add(new Phone { UserId = 10010, AlternateMobileNumber = 12312312, PhoneNumber = 214321423 });
            LoginDetails = new List<LoginDetailInput>();
            LoginDetails.Add(new LoginDetailInput { FullName="Jagdish sahu", Password="test!123",Role="Tester",Username="ABC" });
            LoginDetails.Add(new LoginDetailInput { FullName = "Bharat Taksalia", Password = "test!1234", Role = "Developer", Username = "DEF" });
            LoginDetails.Add(new LoginDetailInput { FullName = "First Last", Password = "test!12345", Role = "Manager", Username = "GHI" });
            LoginDetails.Add(new LoginDetailInput { FullName = "First Last", Password = "test!123456", Role = "Analyst", Username = "JKL" });
        }

        public static List<Member> GetMembers()
        {
            return Members;
        }
        public static Member GetMemberWithId(int Id)
        {
            return Members.Where(i => i.UserId == Id).FirstOrDefault();
        }
        public static int PostMember(Member member)
        {
            int id = Members.Count() + 1;
            member.UserId = id;
            member.IsDeleted = false;
            Members.Add(member);
            return id;
        }
        public static void PutMember(Member member,string username,string password)
        {
            foreach (var item in Members.Where(w => w.UserId == member.UserId))
            {
                item.UserName = username;
                item.Password = password;
            }
            
        }
        public static void DeleteMember(int Id)
        {
            foreach (var item in Members.Where(w => w.UserId == Id))
            {
                Members.Remove(item);
            }
        }
      
        public static Address GetAddressWithId(int Id)
        {
            return Addresses.Where(i => i.UserId == Id).FirstOrDefault();
        }
        public static int PostAddress(Address address)
        {
            Addresses.Add(address);
            return address.UserId;
        }
        public static void PutAddress(Address address, string current, string permanent)
        {
            foreach (var item in Addresses.Where(w => w.UserId == address.UserId))
            {
                item.CurrentAddress = current;
                item.PermanentAddress = permanent;
            }

        }
        public static void DeleteAddress(int Id)
        {
            foreach (var item in Addresses.Where(w => w.UserId == Id))
            {
                Addresses.Remove(item);
            }
        }

        public static List<Phone> GetPhone()
        {
            return Contacts.ToList();
        }

        public static Phone GetPhoneWithId(int Id)
        {
            return Contacts.Where(i => i.UserId == Id).FirstOrDefault();
        }
        public static int PostPhone(Phone phone)
        {
            Contacts.Add(phone);
            return phone.UserId;
        }
        public static void PutPhone(Phone phone, int alternate, int mobile)
        {
            foreach (var item in Contacts.Where(w => w.UserId == phone.UserId))
            {
                item.AlternateMobileNumber = alternate;
                item.PhoneNumber = mobile;
            }

        }
        public static void DeletePhone(int Id)
        {
            foreach (var item in Contacts.Where(w => w.UserId == Id))
            {
                Contacts.Remove(item);
            }
        }
        public static LoginDetailOutput PostLogin(LoginDetailInput input)
        {
            LoginDetailOutput output = new LoginDetailOutput();
            foreach (var item in LoginDetails.Where(w => w.Username ==input.Username && w.Password==input.Password))
            {
                output.Username = item.Username;
                output.Role = item.Role;
                output.FullName=item.FullName;
            }
            return output;
        }
    }
}