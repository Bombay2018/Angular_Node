﻿using ExcelUpload.Models;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web.Mvc;

namespace StudentData.Controllers
{
    public class StudentDetailsController : Controller
    {
        // GET: StudentDetails
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(string button)
        {
            if (button == "Upload File")
            {
                UploadFile();
            }
            else
            {
                SaveData(1, 1);
            }

            return View();
        }

        private ActionResult UploadFile()
        {
            if (Request.Files["FileUpload1"].ContentLength > 0)
            {
                string extension = Path.GetExtension(Request.Files["FileUpload1"].FileName).ToLower();
                string connString = "";

                string[] validFileTypes = { ".xls", ".xlsx", ".csv" };
                FileInfo fileInfo = new FileInfo(Request.Files["FileUpload1"].FileName);

                string path1 = string.Format("{0}/{1}", Server.MapPath("~/Content/Uploads"), fileInfo.Name);
                if (!Directory.Exists(path1))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Content/Uploads"));
                }
                if (validFileTypes.Contains(extension))
                {
                    if (System.IO.File.Exists(path1))
                    { System.IO.File.Delete(path1); }
                    Request.Files["FileUpload1"].SaveAs(path1);
                    if (extension == ".csv")
                    {
                        DataTable dt = Utility.ConvertCSVtoDataTable(path1);
                        TempData["Data"] = dt;
                    }
                    //Connection String to Excel Workbook
                    else if (extension.Trim() == ".xls")
                    {
                        connString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path1 + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=2\"";
                        DataTable dt = Utility.ConvertXSLXtoDataTable(path1, connString);
                        TempData["Data"] = dt;
                    }
                    else if (extension.Trim() == ".xlsx")
                    {
                        connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path1 + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=2\"";
                        DataTable dt = Utility.ConvertXSLXtoDataTable(path1, connString);
                        TempData["Data"] = dt;
                    }
                }
                else
                {
                    ViewBag.Error = "Please Upload Files in .xls, .xlsx or .csv format";
                }
            }
            return View();
        }

        private void SaveData(int userId, int schoolId)
        {
            if (TempData["Data"] as DataTable != null)
            {
                DataTable dt = (TempData["Data"] as DataTable).Copy();
                DataColumn userIdCol = new DataColumn("UserId", typeof(int));
                DataColumn schoolIdCol = new DataColumn("SchoolId", typeof(int));
                DataColumn createDateCol = new DataColumn("CreateDate", typeof(DateTime));
                createDateCol.DefaultValue = DateTime.Now;
                userIdCol.DefaultValue = userId;
                schoolIdCol.DefaultValue = schoolId;
                dt.Columns.Add(userIdCol);
                dt.Columns.Add(schoolIdCol);
                dt.Columns.Add(createDateCol);

                if (dt.Rows.Count > 0)
                {
                    string consString = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
                    using (SqlConnection con = new SqlConnection(consString))
                    {
                        using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(con))
                        {
                            //Set the database table name
                            sqlBulkCopy.DestinationTableName = "dbo.SudentDetails";

                            //[OPTIONAL]: Map the DataTable columns with that of the database table
                            sqlBulkCopy.ColumnMappings.Add("StudentId", "StudentId");
                            sqlBulkCopy.ColumnMappings.Add("UserId", "UserId");
                            sqlBulkCopy.ColumnMappings.Add("SchoolId", "SchoolId");
                            sqlBulkCopy.ColumnMappings.Add("Name", "Name");
                            sqlBulkCopy.ColumnMappings.Add("RollNo", "RollNo");
                            sqlBulkCopy.ColumnMappings.Add("Math", "Math");
                            sqlBulkCopy.ColumnMappings.Add("English", "English");
                            sqlBulkCopy.ColumnMappings.Add("Physics", "Physics");
                            sqlBulkCopy.ColumnMappings.Add("CreateDate", "CreateDate");
                            con.Open();
                            sqlBulkCopy.WriteToServer(dt);
                            con.Close();
                        }
                    }
                }
            }
        }
    }
}