﻿using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Student.DataAccess
{
    public class SQLHelper
    {
        private static string connString = string.Empty;

        static SQLHelper()
        {
            connString = ConfigurationManager.ConnectionStrings["SqlConnectionString"].ConnectionString;
        }

        public static bool ExecuteNonQuery(string storedProcedure, List<SqlParameter> paramList)
        {
            bool result = false;
            using (SqlConnection conn = new SqlConnection(connString))
            {
                if (conn.State != System.Data.ConnectionState.Open)
                {
                    conn.Open();
                }

                using (SqlCommand command = new SqlCommand(storedProcedure, conn))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddRange(paramList.ToArray());

                    int count = command.ExecuteNonQuery();
                    result = count > 0;
                }
            }
            return result;
        }

        public static SqlDataReader ExecuteReader(string storedProcedure, List<SqlParameter> sqlParameterList)
        {
            SqlDataReader drResult = null;
            using (SqlConnection conn = new SqlConnection(connString))
            {
                using (SqlCommand cmd = new SqlCommand(storedProcedure, conn))
                {
                    conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddRange(sqlParameterList.ToArray());

                    drResult = cmd.ExecuteReader();
                }
            }

            return drResult;
        }

        public static DataSet ExecuteDataSet(string storedProcedure, List<SqlParameter> sqlParameterList)
        {
            DataSet dsResult = new DataSet();
            using (SqlConnection conn = new SqlConnection(connString))
            {
                using (SqlCommand cmd = new SqlCommand(storedProcedure, conn))
                {
                    conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddRange(sqlParameterList.ToArray());

                    SqlDataAdapter daResult = new SqlDataAdapter(cmd);

                    daResult.Fill(dsResult);
                }
            }

            return dsResult;
        }
    }
}