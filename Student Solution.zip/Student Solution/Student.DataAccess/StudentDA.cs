﻿using Student.Entities;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System;

namespace Student.DataAccess
{
    public class StudentDA
    {
        public static void SaveStudentsStaging(DataTable dtStudent)
        {
            string connString = ConfigurationManager.ConnectionStrings["SqlConnectionString"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connString))
            {
                using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(conn))
                {
                    sqlBulkCopy.BatchSize = 1000;

                    sqlBulkCopy.DestinationTableName = "dbo.StudentDetailsStaging";

                    sqlBulkCopy.ColumnMappings.Add("StudentId", "StudentId");
                    sqlBulkCopy.ColumnMappings.Add("UserId", "UserId");
                    sqlBulkCopy.ColumnMappings.Add("SchoolId", "SchoolId");
                    sqlBulkCopy.ColumnMappings.Add("Name", "Name");
                    sqlBulkCopy.ColumnMappings.Add("RollNo", "RollNo");
                    sqlBulkCopy.ColumnMappings.Add("Math", "Math");
                    sqlBulkCopy.ColumnMappings.Add("English", "English");
                    sqlBulkCopy.ColumnMappings.Add("Physics", "Physics");
                    sqlBulkCopy.ColumnMappings.Add("CreateDate", "CreateDate");
                    conn.Open();

                    sqlBulkCopy.WriteToServer(dtStudent);
                    conn.Close();
                }
            }
        }

        public static void AddUpdateStudents()
        {
            List<SqlParameter> sqlParameters = new List<SqlParameter>();

            SQLHelper.ExecuteNonQuery("AddUpdateStudents", sqlParameters);
        }

        public static void SaveSchoolTrackingDetails(UploadLog log)
        {
            List<SqlParameter> sqlParameters = new List<SqlParameter>();
            sqlParameters.Add(new SqlParameter("@SchoolId", log.SchoolId));
            sqlParameters.Add(new SqlParameter("@UserId", log.UserId));
            sqlParameters.Add(new SqlParameter("@Descriptions", log.Descriptions));
            sqlParameters.Add(new SqlParameter("@FileName", log.FileName));
            sqlParameters.Add(new SqlParameter("@FilePath", log.FilePath));
            sqlParameters.Add(new SqlParameter("@IsApprovalRequired", log.IsApprovalRequired));
            sqlParameters.Add(new SqlParameter("@IsFileValid", log.IsFileValid));

            SQLHelper.ExecuteNonQuery("SaveSchoolTrackingDetails", sqlParameters);
        }
    }
}