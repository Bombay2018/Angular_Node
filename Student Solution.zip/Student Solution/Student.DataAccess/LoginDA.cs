﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student.DataAccess
{
    public class LoginDA
    {

        public DataSet AuthenticateUser(string loginId, string password)
        {
            List<SqlParameter> sqlParameterList = new List<SqlParameter>();
            sqlParameterList.Add(new SqlParameter("LoginID", loginId));
            sqlParameterList.Add(new SqlParameter("Password", password));

            DataSet dsLogin = SQLHelper.ExecuteDataSet("AuthenticateUser", sqlParameterList);

            return dsLogin;
        }
    }
}
