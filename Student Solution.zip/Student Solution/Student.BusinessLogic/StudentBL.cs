﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Student.DataAccess;
using Student.Entities;

namespace Student.BusinessLogic
{
    public class StudentBL
    {
        public static void SaveStudentsStaging(DataTable dtStudent, int schoolId, int userId)
        {
            DataColumn userIdCol = new DataColumn("UserId", typeof(int));
            DataColumn schoolIdCol = new DataColumn("SchoolId", typeof(int));
            DataColumn createDateCol = new DataColumn("CreateDate", typeof(DateTime));

            createDateCol.DefaultValue = DateTime.Now;
            userIdCol.DefaultValue = userId;
            schoolIdCol.DefaultValue = schoolId;
            dtStudent.Columns.Add(userIdCol);
            dtStudent.Columns.Add(schoolIdCol);
            dtStudent.Columns.Add(createDateCol);

            StudentDA.SaveStudentsStaging(dtStudent);
        }

        public static void SaveSchoolTrackingDetails(UploadLog log)
        {
            StudentDA.SaveSchoolTrackingDetails(log);
        }

        public static void AddUpdateStudents()
        {
            StudentDA.AddUpdateStudents();
        }
    }
}
