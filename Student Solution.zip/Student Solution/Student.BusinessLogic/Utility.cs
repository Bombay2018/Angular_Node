﻿using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.IO;

namespace Student.BusinessLogic
{
    public static class Utility
    {
        public static DataTable ConvertXlsxToDataTable(string filePath)
        {
            string connString = GetExcelConnectionString(filePath);

            DataTable dtExcelData = new DataTable();
            using (OleDbConnection conn = new OleDbConnection(connString))
            {
                conn.Open();
                using (OleDbCommand cmd = new OleDbCommand("SELECT * FROM [Sheet1$]", conn))
                {
                    OleDbDataAdapter oleda = new OleDbDataAdapter(cmd);
                    oleda.SelectCommand = cmd;
                    DataSet dsExcelData = new DataSet();
                    oleda.Fill(dsExcelData);

                    dtExcelData = dsExcelData.Tables[0];
                }
            }

            return dtExcelData;
        }

        private static string GetExcelConnectionString(string filePath)
        {
            FileInfo fileInfo = new FileInfo(filePath);

            if (fileInfo.Extension.ToLower() == ".xls")
            {
                return string.Format(ConfigurationManager.ConnectionStrings["OledbXlsConnectionString"].ConnectionString, filePath);
            }
            else if (fileInfo.Extension.ToLower() == ".xlsx")
            {
                return string.Format(ConfigurationManager.ConnectionStrings["OledbXlsxConnectionString"].ConnectionString, filePath);
            }

            return "";
        }
    }
}