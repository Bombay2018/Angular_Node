﻿using Student.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student.BusinessLogic
{
    public class LoginBL
    {
        static LoginDA loginDA = null;
        static LoginBL()
        {
            loginDA = new LoginDA();
        }

        public bool AuthenticateUser(string loginId, string password, ref string userName, ref string errorMessage)
        {
            DataSet dsLogin = loginDA.AuthenticateUser(loginId, password);

            if (dsLogin.Tables.Count > 0 && dsLogin.Tables[0].Rows.Count > 0)
            {
                userName = Convert.ToString(dsLogin.Tables[0].Rows[0]["UserName"]);

                return true;
            }

            errorMessage = "Invalid Login ID or Password";
            return false;
        }
    }
}
