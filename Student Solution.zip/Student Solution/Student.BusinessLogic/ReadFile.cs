﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student.BusinessLogic
{
    public class ReadFile
    {
        public string ReadTextFile(string filePath)
        {
            string result = string.Empty;
                // Read the file as one string.
                result = System.IO.File.ReadAllText(filePath);
            return result;
        }

    }
}
