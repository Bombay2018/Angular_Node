﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace Student.BusinessLogic
{
    public class SendMailHelper
    {
        private const int TimeoutDuration = 110000;
        private readonly string _hostNumber;
        private readonly int _portNumber;
        private readonly string _userName;
        private readonly string _password;
        private readonly bool _sslCertificate;
        public SendMailHelper()
        {
            _hostNumber = ConfigurationManager.AppSettings["MailServer"];
            _portNumber = int.Parse(ConfigurationManager.AppSettings["Port"]);
            _userName = ConfigurationManager.AppSettings["MailAuthUser"];
            _password = ConfigurationManager.AppSettings["MailAuthPass"];
            _sslCertificate = Convert.ToBoolean(ConfigurationManager.AppSettings["EnableSSL"]);
        }

        public void SendMail(string From, string To, string CC, string BCC, string Subject, string Body, string AttachmentFile)
        {
                Attachment attachments = null;
                var message = new MailMessage(From, To, Subject, Body) { IsBodyHtml = true };
                if (CC != null)
                {
                    message.CC.Add(CC);
                }
                if (BCC != null)
                {
                    message.Bcc.Add(BCC);
                }
                var smtp = new SmtpClient(_hostNumber, _portNumber);

                if (!String.IsNullOrEmpty(AttachmentFile))
                {
                    if (File.Exists(AttachmentFile))
                    {
                        attachments = new Attachment(AttachmentFile);
                        message.Attachments.Add(attachments);
                    }
                }

                if (_userName.Length > 0 && _password.Length > 0)
                {
                    smtp.UseDefaultCredentials = false;
                    smtp.Credentials = new NetworkCredential(_userName, _password);
                    smtp.EnableSsl = _sslCertificate;
                }

                smtp.Send(message);

                if (attachments != null)
                {
                    attachments.Dispose();                    
                }

                message.Dispose();
                smtp.Dispose();
        }

        public void SendUploadFailed(string Name, string From, string To, string CC, string BCC, string Subject, string AttachmentFile, string filePath)
        {
            ReadFile fileReader = new ReadFile();
            string mailBody = fileReader.ReadTextFile(filePath)
                                    .Replace("%%USERNAME%%", Name)
                                    .Replace("%%TIMESTAMP%%", DateTime.Now.ToShortDateString());
            var SendMailHelper = new SendMailHelper();
            SendMailHelper.SendMail(From, To, CC, BCC, Subject, mailBody, AttachmentFile);
        }

    }
}
