﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StudentWebApp.Models
{
    public class StudentModel
    {
        public int StudentId { get; set; }

        public int SchoolId { get; set; }

        public int UserId { get; set; }

        public string Name { get; set; }

        public string RollNo { get; set; }

        public int Math { get; set; }

        public int English { get; set; }

        public int Physics { get; set; }
    }
}