﻿namespace StudentWebApp.Models
{
    public class SchoolModel
    {
        public int SchoolId { get; set; }

        public string SchoolName { get; set; }

        public string FileName { get; set; }
    }
}