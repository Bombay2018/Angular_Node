﻿using System.Web.Mvc;

namespace StudentWebApp
{
    public class CustomExceptionAttribute : FilterAttribute, IExceptionFilter
    {
        public void OnException(ExceptionContext filterContext)
        {
            filterContext.ExceptionHandled = true;

            filterContext.Result = new ViewResult
            {
                ViewName = "~/Views/Shared/ErrorPage.cshtml",
                MasterName = "~/Views/Shared/_Layout.cshtml"
            };
        }
    }
}