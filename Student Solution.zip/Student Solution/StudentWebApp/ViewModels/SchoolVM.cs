﻿using StudentWebApp.Models;
using System.Collections.Generic;

namespace StudentWebApp.ViewModels
{
    public class SchoolVM
    {
        public List<SchoolModel> Schools { get; set; }

        public string Message { get; set; }

        public string MessageColor { get; set; }
    }
}