﻿using StudentWebApp.Models;
using System.Collections.Generic;

namespace StudentWebApp.ViewModels
{
    public class StudentVM
    {
        public List<StudentModel> Students { get; set; }

        public string Message { get; set; }

        public string MessageColor { get; set; }

        private string _diplaySaveButton = "none";

        public string DisplaySaveButton
        {
            get { return _diplaySaveButton; }
            set { _diplaySaveButton = value; }
        }

        private string _showApprovalButton = "N";

        public string ShowApprovalButton
        {
            get { return _showApprovalButton; }
            set { _showApprovalButton = value; }
        }
    }
}