﻿using Student.BusinessLogic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using StudentWebApp.ViewModels;
using System.Web.Security;

namespace StudentWebApp.Controllers
{
    [AllowAnonymous]
    public class LoginController : Controller
    {
        public ActionResult Index()
        {
            return View("Login", new LoginVM());
        }

        public ActionResult ValidateUser(LoginVM loginVM)
        {
            if(string.IsNullOrWhiteSpace(loginVM.LoginId) || string.IsNullOrWhiteSpace(loginVM.Password))
            {
                loginVM.Message = "Please enter both Login ID and Password.";
                return View("Login", loginVM);
            }

            LoginBL loginBL = new LoginBL();
            string userName = string.Empty;
            string errorMessage = string.Empty;

            bool isAuthenticated = loginBL.AuthenticateUser(loginVM.LoginId, loginVM.Password, ref userName, ref errorMessage);

            if (isAuthenticated)
            {
                FormsAuthentication.SetAuthCookie(userName, loginVM.RememberMe);
                return RedirectToAction("Index", "Home");
            }

            loginVM.Message = errorMessage;

            return View("Login", loginVM);
        }

        [Authorize]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }
    }
}