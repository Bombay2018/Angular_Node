﻿using Student.BusinessLogic;
using Student.Entities;
using StudentWebApp.Models;
using StudentWebApp.ViewModels;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web.Mvc;
using Excel = Microsoft.Office.Interop.Excel;

namespace StudentWebApp.Controllers
{
    public class StudentController : Controller
    {
        public ActionResult Load()
        {
            //var SendMailHelper = new SendMailHelper();
            //SendMailHelper.SendUploadFailed("Actual User Name","User@techmahindra.com", "User@techmahindra.com", null, null, "Upload Failure - Student Information System", null, Server.MapPath("~/Content/MailTemplates/MailUploadFailure.txt"));

            return View("Student", new StudentVM());
        }

        [SubmitButtonSelector(Name = "Upload")]
        public ActionResult Upload()
        {
            StudentVM modelView = new StudentVM();
            int schoolId = 1; //ToDo: will come from logged in school

            string errorMessage = ValidateFile();
            if (errorMessage == string.Empty)
            {
                string filePath = SaveUploadFile(schoolId);
                TempData["filePath"] = filePath;

                DataTable dtStudents = GetStudents(filePath);
                errorMessage = ValidateUploadedFile(dtStudents, filePath);
                if (errorMessage == string.Empty)
                {
                    modelView.Students = GetStudents(dtStudents);
                    modelView.DisplaySaveButton = string.Empty;
                }
                else
                {
                    modelView.ShowApprovalButton = "Y";
                }
            }

            modelView.Message = errorMessage;
            modelView.MessageColor = "red";

            return View("Student", modelView);
        }

        [SubmitButtonSelector(Name = "Download")]
        public ActionResult Download()
        {
            ExportToExcel();
            return View("Student", new StudentVM());
        }

        [SubmitButtonSelector(Name = "Save")]
        public ActionResult Save()
        {
            StudentVM modelView = new StudentVM();
            int schoolId = 1; //ToDo: will come from logged in school
            int userId = 4; //ToDo: will come from logged in user

            string filePath = Convert.ToString(TempData["filePath"]);
            if (!string.IsNullOrEmpty(filePath))
            {
                DataTable dtStudent = GetStudents(filePath);
                if (dtStudent != null && dtStudent.Rows.Count > 0)
                {
                    StudentBL.SaveStudentsStaging(dtStudent, schoolId, userId);

                    StudentBL.AddUpdateStudents();
                    modelView.Message = "Record saved successfully";
                    modelView.MessageColor = "green";
                }

                //Save excel file on pysical local if file is valid.
                //SaveSchoolTrackingDetails(filePath, schoolId, userId, true, false, string.Empty);
            }

            return View("Student", modelView);
        }

        [HttpPost]
        public void RequestApproval(string desc)
        {
            string filePath = Convert.ToString(TempData["filePath"]);
            if (!string.IsNullOrEmpty(filePath))
            {
                int schoolId = 1; //ToDo: will come from logged in school
                int userId = 4; //ToDo: will come from logged in user
                SaveSchoolTrackingDetails(filePath, schoolId, userId, false, true, desc);
            }
        }

        public ActionResult GetSchoolTrackingDetails()
        {
            SchoolVM modelView = new SchoolVM();
            modelView.Schools = GetSchools();
            return View("School", modelView);
        }

        public ActionResult GetIncorrectExcelFiles(string fileName)
        {
            string incorrectExcelFilePath = string.Format("{0}\\{1}", Server.MapPath("~/Content/Uploads"), fileName);
            DataTable incorrectExcelDataTable = GetStudents(incorrectExcelFilePath);

            string templatePath = Server.MapPath("~//Content//Template//StudentExcelTemplate.xlsx");
            DataTable templateDataTable = Utility.ConvertXlsxToDataTable(templatePath);

            TempData["IncorrectExcelDataTable"] = incorrectExcelDataTable;
            TempData["TemplateDataTable"] = templateDataTable;
            return View("SchoolTrackingDetails");
        }

        private void SaveSchoolTrackingDetails(string sourceFilePath, int schoolId, int userId, bool isFileValid, bool isApprovalRequired, string description)
        {
            FileInfo fileInfo = new FileInfo(sourceFilePath);

            string descFilePath = Server.MapPath("~/Content/Uploads") + "/" + fileInfo.Name;
            System.IO.File.Copy(sourceFilePath, descFilePath, true);

            if (System.IO.File.Exists(descFilePath))
            {
                UploadLog log = new UploadLog()
                {
                    SchoolId = schoolId,
                    UserId = userId,
                    Descriptions = description,
                    FileName = fileInfo.Name,
                    FilePath = Path.GetDirectoryName(descFilePath),
                    IsFileValid = isFileValid,
                    IsApprovalRequired = isApprovalRequired
                };

                StudentBL.SaveSchoolTrackingDetails(log);
            }
        }

        private string ValidateFile()
        {
            string errorMessage = string.Empty;
            if (Request.Files["fileUpload"].ContentLength <= 0)
            {
                errorMessage = "Please select upload file.";
            }
            else
            {
                FileInfo fileInfo = new FileInfo(Request.Files["fileUpload"].FileName);
                string[] validFileTypes = { ".xls", ".xlsx" };
                if (!validFileTypes.Contains(fileInfo.Extension))
                {
                    errorMessage = "Please upload file in .xls or .xlsx format only.";
                }
            }

            return errorMessage;
        }

        private string SaveUploadFile(int schoolId)
        {
            FileInfo fileInfo = new FileInfo(Request.Files["fileUpload"].FileName);
            string fileName = Path.GetFileNameWithoutExtension(fileInfo.Name) + "_" + schoolId + "_" + DateTime.Now.ToString("ddMMyyyy") + fileInfo.Extension;

            string filePath = Path.GetTempPath() + fileName;

            if (System.IO.File.Exists(filePath))
            {
                System.IO.File.Delete(filePath);
            }

            Request.Files["fileUpload"].SaveAs(filePath);

            return filePath;
        }

        private DataTable GetStudents(string filePath)
        {
            DataTable dtStudent = new DataTable();

            FileInfo fileInfo = new FileInfo(filePath);
            string extension = fileInfo.Extension.ToLower();

            if (fileInfo.Exists && (extension == ".xls" || extension == ".xlsx"))
            {
                dtStudent = Utility.ConvertXlsxToDataTable(filePath);
            }

            return dtStudent;
        }

        private List<StudentModel> GetStudents(DataTable dtStudent)
        {
            List<StudentModel> students = new List<StudentModel>();
            foreach (DataRow drRow in dtStudent.Rows)
            {
                StudentModel student = new StudentModel()
                {
                    StudentId = Convert.ToInt32(drRow["StudentId"]),
                    Name = Convert.ToString(drRow["Name"]),
                    RollNo = Convert.ToString(drRow["RollNo"]),
                    English = Convert.ToInt32(drRow["English"]),
                    Math = Convert.ToInt32(drRow["Math"]),
                    Physics = Convert.ToInt32(drRow["Physics"])
                };

                students.Add(student);
            }

            return students;
        }

        private void ExportToExcel()
        {
            string conn = ConfigurationManager.ConnectionStrings["SqlConnectionString"].ConnectionString;

            string data = null;

            Excel.Application xlApp = new Excel.Application();

            Excel.Workbook xlWorkBook = xlApp.Workbooks.Add(Missing.Value);

            Excel.Worksheet xlWorkSheet = (Excel.Worksheet)xlWorkBook.ActiveSheet;

            object misValue = Missing.Value;

            xlApp.Visible = false;

            using (SqlConnection con = new SqlConnection(conn))
            {
                con.Open();

                using (SqlCommand cmd = new SqlCommand("SELECT * FROM StudentDetails", con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        int k = 0;

                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            data = (reader.GetName(i));

                            xlWorkSheet.Cells[1, k + 1] = data;

                            k++;
                        }

                        char lastColumn = (char)(65 + reader.FieldCount - 1);

                        xlWorkSheet.get_Range("A1", lastColumn + "1").Font.Bold = true;

                        xlWorkSheet.get_Range("A1", lastColumn + "1").VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;

                        reader.Close();
                    }

                    using (SqlDataAdapter dataAdapter = new SqlDataAdapter())
                    {
                        dataAdapter.SelectCommand = cmd;
                        using (DataSet dataSet = new DataSet())
                        {
                            dataAdapter.Fill(dataSet);

                            for (int i = 0; i <= dataSet.Tables[0].Rows.Count - 1; i++)
                            {
                                var newj = 0;

                                for (int j = 0; j <= dataSet.Tables[0].Columns.Count - 1; j++)
                                {
                                    data = dataSet.Tables[0].Rows[i].ItemArray[j].ToString();

                                    xlWorkSheet.Cells[i + 2, newj + 1] = data;

                                    newj++;
                                }
                            }
                        }
                    }
                }
            }
            xlWorkBook.Close(true, misValue, misValue);

            xlApp.Quit();

            ReleaseObject(xlWorkSheet);

            ReleaseObject(xlWorkBook);

            ReleaseObject(xlApp);
        }

        private void ReleaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch
            {
                obj = null;
            }
            finally
            {
                GC.Collect();
            }
        }

        private string ValidateUploadedFile(DataTable uploadedDatatable, string filePath)
        {
            string templatePath = Server.MapPath("~//Content//Template//StudentExcelTemplate.xlsx");
            DataTable dtTemplate = Utility.ConvertXlsxToDataTable(templatePath);

            // Validating uploaded sheet's and template sheet's column count
            if (uploadedDatatable.Columns.Count != dtTemplate.Columns.Count)
            {
                return MessageHelper.HeaderColumnCountMismatch;
            }

            // Validating uploaded sheet's column order and header text mismatch with the existing template
            for (int i = 0; i < uploadedDatatable.Columns.Count; i++)
            {
                if (uploadedDatatable.Columns[i].ColumnName.Trim().ToLower() != dtTemplate.Columns[i].ColumnName.Trim().ToLower())
                {
                    return MessageHelper.HeaderOrderMismatch;
                }
            }

            // Validating uploaded sheet for blank rows and columns
            if (uploadedDatatable.Columns.Count == 0 || uploadedDatatable.Rows.Count == 0)
            {
                return MessageHelper.BlankExcel;
            }

            // Validating uploaded sheet's rows data types
            foreach (DataRow uploadedRow in uploadedDatatable.Rows)
            {
                if (!(uploadedRow.ItemArray[0].GetType() == typeof(double) &&
                    uploadedRow.ItemArray[3].GetType() == typeof(double) &&
                    uploadedRow.ItemArray[4].GetType() == typeof(double) &&
                    uploadedRow.ItemArray[5].GetType() == typeof(double)))
                {
                    return MessageHelper.InvalidDataFormat;
                }
            }

            return string.Empty;
        }

        private List<SchoolModel> GetSchools()
        {
            string conn = ConfigurationManager.ConnectionStrings["SqlConnectionString"].ConnectionString;
            List<SchoolModel> schoolList = new List<SchoolModel>();
            using (SqlConnection con = new SqlConnection(conn))
            {
                con.Open();

                using (SqlCommand cmd = new SqlCommand("Select SD.Id, SD.SchoolName, STD.FileName, STD.FilePath from dbo.SchoolTrackingDetails STD join dbo.SchoolDetails SD on STD.SchoolId = SD.Id", con))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
                    DataSet dataSet = new DataSet();
                    dataAdapter.Fill(dataSet);
                    DataTable dtSchool = dataSet.Tables[0];

                    foreach (DataRow drRow in dtSchool.Rows)
                    {
                        SchoolModel school = new SchoolModel()
                        {
                            SchoolId = Convert.ToInt32(drRow["Id"]),
                            SchoolName = Convert.ToString(drRow["SchoolName"]),
                            FileName = Convert.ToString(drRow["FileName"])
                        };

                        schoolList.Add(school);
                    }
                    return schoolList;
                }
            }
        }
    }
}