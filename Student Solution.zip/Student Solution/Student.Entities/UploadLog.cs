﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Student.Entities
{
    public class UploadLog
    {
        public int SchoolId { get; set; }

        public int UserId { get; set; }

        public string Descriptions { get; set; }

        public string FileName { get; set; }

        public string FilePath { get; set; }

        public bool IsApprovalRequired { get; set; }

        public bool IsFileValid { get; set; }
    }
}