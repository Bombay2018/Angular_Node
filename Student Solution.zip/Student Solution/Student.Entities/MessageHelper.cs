﻿using System;

namespace Student.Entities
{
    public class MessageHelper
    {
        public static string BlankExcel
        {
            get { return "The template you are trying to upload is blank. Please fill in and try to upload again."; }
        }

        public static string HeaderOrderMismatch
        {
            get { return "The template you are trying to upload is not valid. Please place header column in correct order"; }
        }

        public static string HeaderColumnCountMismatch
        {
            get { return "The template you are trying to upload is not valid. Please place valid header column count"; }
        }

        public static string InvalidDataFormat
        {
            get { return "The template you are trying to upload is not valid. Please validate columns values"; }
        }
    }
}