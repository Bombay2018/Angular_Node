﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APIToolProject.BusinessLogic
{
    public class TreeView
    {
        public string name { get; set; }
        public string id { get; set; }
        public List<TreeView> children { get; set; }
    }

    public class TreeViewMenu
    {
        public List<TreeView> Menu { get; set; }
    }
}
