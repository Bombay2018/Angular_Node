﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIToolProject.DataAccess;
using System.Data;

namespace APIToolProject.BusinessLogic
{
    public class ApiToolBL
    {
        public static TreeViewMenu GetApiMenu()
        {
            TreeViewMenu menu = new TreeViewMenu();
            menu.Menu = new List<TreeView>();

            DataSet dsMenu = ApiToolDA.GetApiMenu();

            List<TreeView> child = new List<TreeView>();
            if (dsMenu.Tables.Count > 0 && dsMenu.Tables[0].Rows.Count > 0)
            {
                DataTable dtMenuCat = dsMenu.Tables[0].DefaultView.ToTable(true, "CATEGORYID", "CATEGORY");

                menu.Menu.Add(new TreeView { name = "API Documentation", id = "0", children = getCategoryData(child, dsMenu) });
            }

            return menu;
        }

        public static ContentTreeView GetApiContent(int apiMethodId)
        {
            ContentTreeView contentTreeView = new ContentTreeView();

            DataSet dsContent = ApiToolDA.GetApiContent(apiMethodId);
            if (dsContent.Tables.Count > 0 && dsContent.Tables[0].Rows.Count > 0)
            {
                contentTreeView.Content.Add(new Content()
                {
                    ServiceProvider = new ServiceProvider()
                    {
                        ProviderName = Convert.ToString(dsContent.Tables[0].Rows[0]["ProviderName"]),
                        ModifiedDate = Convert.ToDateTime(dsContent.Tables[0].Rows[0]["ModifiedDate"]).ToString("dd-MMM-yyyy")
                    },

                    Documentation = new Documentation()
                    {
                        Name = Convert.ToString(dsContent.Tables[0].Rows[0]["APINAME"]),
                        Description = Convert.ToString(dsContent.Tables[0].Rows[0]["APIDESCRIPTIONS"]),
                        ImportantDescription = Convert.ToString(dsContent.Tables[0].Rows[0]["IMPORTANTDESCRIPTIONS"])
                    },

                    ServiceUrl = new ServiceUrl()
                    {
                        Name = "Service Url",
                        UrlDetails = GetUrlDetails(dsContent.Tables[0])
                    },

                    RequestParam = new RequestParam()
                    {
                        Name = "Input Parameter",
                        InputParam = GetInputParameters(dsContent)
                    },

                    SampleRequest = Convert.ToString(dsContent.Tables[0].Rows[0]["SAMPLEINPUT"]),

                    ResponseParam = new ResponseParam()
                    {
                        Name = "Output Parameter",
                        OutputParam = GetOutputParameters(dsContent)
                    },

                    SampleResponse = Convert.ToString(dsContent.Tables[0].Rows[0]["SAMPLEOUTPUT"])
                });
            }

            return contentTreeView;
        }

        private static List<InputOutputParam> GetOutputParameters(DataSet dsContent)
        {
            List<InputOutputParam> outputs = new List<InputOutputParam>();

            if (dsContent.Tables.Count > 2)
            {
                foreach (DataRow drOutput in dsContent.Tables[2].Rows)
                {
                    outputs.Add(new InputOutputParam()
                    {
                        ParameterName = Convert.ToString(drOutput["OUTPUTPARAMETERNAME"]),
                        ParameterType = Convert.ToString(drOutput["OUTPUTPARAMETERTYPE"]),
                        Description = Convert.ToString(drOutput["OUTPUTPARAMETERDESC"])
                    });
                }
            }
            return outputs;
        }

        private static List<InputOutputParam> GetInputParameters(DataSet dsContent)
        {
            List<InputOutputParam> inputs = new List<InputOutputParam>();

            if (dsContent.Tables.Count > 1)
            {
                foreach (DataRow drOutput in dsContent.Tables[1].Rows)
                {
                    inputs.Add(new InputOutputParam()
                    {
                        ParameterName = Convert.ToString(drOutput["INPUTPARAMETERNAME"]),
                        ParameterType = Convert.ToString(drOutput["INPUTPARAMETERTYPE"]),
                        Description = Convert.ToString(drOutput["INPUTPARAMETERDESC"])

                    });
                }
            }
            return inputs;
        }

        private static List<UrlDetails> GetUrlDetails(DataTable dtApi)
        {
            List<UrlDetails> urlDetails = new List<UrlDetails>();

            urlDetails.Add(new UrlDetails()
            {
                Environment = "Dev",
                Url = Convert.ToString(dtApi.Rows[0]["APIURL_DEV"])
            });

            urlDetails.Add(new UrlDetails()
            {
                Environment = "QA",
                Url = Convert.ToString(dtApi.Rows[0]["APIURL_QC"])
            });

            urlDetails.Add(new UrlDetails()
            {
                Environment = "Prod",
                Url = Convert.ToString(dtApi.Rows[0]["APIURL_PROD"])
            });

            return urlDetails;
        }

        public static List<TreeView> getCategoryData(List<TreeView> children, DataSet dsMenu)
        {
            children = new List<TreeView>();

            DataTable dtMenuCat = dsMenu.Tables[0].DefaultView.ToTable(true, "CATEGORYID", "CATEGORY");

            foreach (DataRow row in dtMenuCat.Rows)
            {
                DataTable dtMenuSubCat = dsMenu.Tables[0].DefaultView.ToTable(true, "SUBCATEGORYID", "SUBCATEGORY", "CATEGORYID");

                DataRow[] drMenuSubCat = dtMenuSubCat.Select("CATEGORYID=" + Convert.ToString(row["CATEGORYID"]));
                children.Add(new TreeView
                {
                    name = Convert.ToString(row["CATEGORY"]),
                    id = "",

                    children = getSubcategoryData(drMenuSubCat, dsMenu)
                });
            }

            return children;
        }

        public static List<TreeView> getSubcategoryData(DataRow[] rows, DataSet dsMenu)
        {
            List<TreeView> subChildren = new List<TreeView>();

            foreach (DataRow row in rows)
            {
                DataRow[] drMenuSubCat = dsMenu.Tables[0].Select("SUBCATEGORYID=" + Convert.ToString(row["SUBCATEGORYID"]));
                foreach (DataRow drRow in drMenuSubCat)
                {
                    subChildren.Add(new TreeView
                    {
                        name = Convert.ToString(drRow["APINAME"]),
                        id = Convert.ToString(drRow["APIMETHODID"]),
                    });
                }
            }

            return subChildren;
        }
    }
}
