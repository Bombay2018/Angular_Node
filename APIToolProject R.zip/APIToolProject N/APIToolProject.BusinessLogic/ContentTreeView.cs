﻿using System.Collections.Generic;

namespace APIToolProject.BusinessLogic
{
    public class ContentTreeView
    {
        private List<Content> _Content = new List<Content>();

        public List<Content> Content
        {
            get { return _Content; }
            set { _Content = value; }
        }
    }

    public class Content
    {
        private ServiceProvider _ServiceProvider = new ServiceProvider();

        public ServiceProvider ServiceProvider
        {
            get { return _ServiceProvider; }
            set { _ServiceProvider = value; }
        }

        private Documentation _Documentation = new Documentation();

        public Documentation Documentation
        {
            get { return _Documentation; }
            set { _Documentation = value; }
        }

        private ServiceUrl _ServiceUrl = new ServiceUrl();

        public ServiceUrl ServiceUrl
        {
            get { return _ServiceUrl; }
            set { _ServiceUrl = value; }
        }

        private RequestParam _RequestParam = new RequestParam();

        public RequestParam RequestParam
        {
            get { return _RequestParam; }
            set { _RequestParam = value; }
        }

        public string SampleRequest { get; set; }

        private ResponseParam _ResponseParam = new ResponseParam();

        public ResponseParam ResponseParam
        {
            get { return _ResponseParam; }
            set { _ResponseParam = value; }
        }

        public string SampleResponse { get; set; }
    }

    public class ServiceProvider
    {
        public string ModifiedDate { get; set; }

        public string ProviderName { get; set; }
    }

    public class Documentation
    {
        public string Name { get; set; }

        public string Description { get; set; }

        public string ImportantDescription { get; set; }
    }

    public class ServiceUrl
    {
        public string Name { get; set; }

        private List<UrlDetails> _UrlDetails = new List<UrlDetails>();

        public List<UrlDetails> UrlDetails
        {
            get { return _UrlDetails; }
            set { _UrlDetails = value; }
        }
    }

    public class UrlDetails
    {
        public string Environment { get; set; }

        public string Url { get; set; }
    }

    public class RequestParam
    {
        public string Name { get; set; }

        public List<InputOutputParam> InputParam { get; set; }
    }

    public class ResponseParam
    {
        public string Name { get; set; }

        public List<InputOutputParam> OutputParam { get; set; }
    }

    public class InputOutputParam
    {
        public string ParameterName { get; set; }

        public string ParameterType { get; set; }

        public string Description { get; set; }
    }
}