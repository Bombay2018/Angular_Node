﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APIToolProject.DataAccess
{
    public class ApiToolDA
    {
        public static DataSet GetApiMenu()
        {
            List<SqlParameter> sqlParameters = new List<SqlParameter>();

            DataSet dsMenu = SQLHelper.ExecuteDataSet("GETMENUDETAILS", sqlParameters);

            return dsMenu;
        }

        public static DataSet GetApiContent(int apiMethodId)
        {
            List<SqlParameter> sqlParameters = new List<SqlParameter>();
            sqlParameters.Add(new SqlParameter("@APIMETHODID", apiMethodId));

            DataSet dsContent = SQLHelper.ExecuteDataSet("GETAPIMETHODDETAILS", sqlParameters);

            return dsContent;
        }
    }
}
