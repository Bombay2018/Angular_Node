﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APIToolProject.DataAccess
{
    public class SQLHelper
    {
        private static string connString = string.Empty;

        static SQLHelper()
        {
            connString = ConfigurationManager.ConnectionStrings["SqlConnectionString"].ConnectionString;
        }

        public static DataSet ExecuteDataSet(string storedProcedure, List<SqlParameter> sqlParameterList)
        {
            DataSet dsResult = new DataSet();
            using (SqlConnection conn = new SqlConnection(connString))
            {
                using (SqlCommand cmd = new SqlCommand(storedProcedure, conn))
                {
                    conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddRange(sqlParameterList.ToArray());

                    SqlDataAdapter daResult = new SqlDataAdapter(cmd);

                    daResult.Fill(dsResult);
                }
            }

            return dsResult;
        }
    }
}
