﻿using APIToolProject.BusinessLogic;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;
using System.Web.Script.Services;
using System.Web.Services;

namespace APIToolProject
{
    /// <summary>
    /// Summary description for ApiTool
    /// </summary>
    [WebService(Namespace = "http://techmahindra.com/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
    [System.Web.Script.Services.ScriptService]
    public class ApiTool : System.Web.Services.WebService
    {
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string Menu()
        {
            TreeViewMenu menu = ApiToolBL.GetApiMenu();

            return JsonConvert.SerializeObject(menu);
        }



        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string Content(string apiMethodId)
        {

            ContentTreeView contentTreeView = ApiToolBL.GetApiContent(Convert.ToInt32(apiMethodId));

            return JsonConvert.SerializeObject(contentTreeView);
        }
    }
}