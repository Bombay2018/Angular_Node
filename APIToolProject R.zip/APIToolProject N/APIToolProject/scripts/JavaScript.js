﻿
$(document).ready(function () {
    $("#btnStore").click(function (e) {
        //var count = 60;
        //var counter = setInterval(timer, 1000); //1000 will  run it every 1 second
        //function timer() {
        //    count = count - 1;
        //    if (count <= 0) {
        //        clearInterval(counter);
        //        $("#divSessionData").html("Session is Invalid");
        //        //counter ended, do something here
        //        return;
        //    }
        //    var strHtml = "<h3>Session is Valid</h3>" + count.toString();

        //    $("#divSessionData").html(strHtml);
        //    //Do code for showing the number of seconds here
        //}
        var d = "Hello, World";
        var url = "/WebService1.asmx/HelloWorld"; // the script where you handle the form input.

        $.ajax({
            type: "POST",
            url: url,
            data: JSON.stringify(d), // serializes the form's elements.
            success: function (data) {
                if (data === "1") {
                    var strHtml = "<h3>Session is Valid</h3>";
                    
                    $("#divSessionData").html(strHtml);
                }
                else {
                    var strHtml = "<h3>Session is InValid</h3>"
                    $("#divSessionData").html(strHtml);
                }
            },
            error: function (e) {
                console.log(e);
            }
        });

        
    });



    

    


    $("#btnCheckSession").click(function (e) {

        var d = "Hello, World";
        var url = "/WebService1.asmx/CheckSession"; // the script where you handle the form input.
        
        $.ajax({
            type: "POST",
            url: url,
            data: JSON.stringify(d), // serializes the form's elements.
            success: function (data) {
                if (data === "1") {
                    var strHtml = "<h3>Session is Valid</h3>";

                    $("#divSessionData").html(strHtml);
                }
                else {
                    var strHtml = "<h3>Session is InValid</h3>"
                    $("#divSessionData").html(strHtml);
                }
            },
            error: function (e) {
                console.log(e);
            }
        });


    });


});
