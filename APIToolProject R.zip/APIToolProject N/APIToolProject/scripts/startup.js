﻿var url = "";

$(document).ready(function () {
   
    url = "/ApiTool.asmx/Menu";

    $.ajax({
        type: "POST",
        url: url,
        dataType: 'json',
        contentType: 'application/json; charset=utf-8',
        success: function (data) {
            var menu = (JSON.parse(data.d)).Menu;
            $('#menuId').tree({
                data: menu,
                autoOpen: true,
                dragAndDrop: true
            });
            $("ul.mx__breadcrumb").empty();
            $("ul.mx__breadcrumb").append("<li>API Documentation</li>").append("<li>Story</li>").append("<li>Microflow CreateStory</li>");
            getAPIData(2);
        },
        error: function (e) {
        }
    });

   

    createBreadCrumbs();   

});

function createBreadCrumbs()
{
    $('#menuId').bind(
    'tree.click',
    function (event) {
        // The clicked node is 'event.node'
        var node = event.node;
        var id = node.id;

        //Call Webservice method to fetch data
        getAPIData(id);
        // Create BreadCrumbs
        var currentNode = event.node;
        var level = currentNode.getLevel();
        var nodes = [];
        nodes.push(currentNode);
        for (i = 1; i < level; i++) {
            nodes.push(currentNode.parent);
            currentNode = currentNode.parent;
        }
        nodes = nodes.reverse();
        var breadcrumb = "";
        $("ul.mx__breadcrumb").empty();
        for (j = 0; j < level; j++) {
            if (j !== level - 1) {
                breadcrumb = breadcrumb + nodes[j].name + " /";
            }
            else {
                breadcrumb = breadcrumb + nodes[j].name;
            }

            //$("ul.mx__breadcrumb").append("<li><a href='#' title='" + nodes[j].name + "'>" + nodes[j].name + "</a></li>");
            $("ul.mx__breadcrumb").append("<li>"+ nodes[j].name + "</li>");
        }
    });
}

function getAPIData(id)
{
    if (id !== 0 && id !== undefined && id.length !== 0) {
        url = "/ApiTool.asmx/Content";
        $.ajax({
            type: "POST",
            url: url,
            data: "{'apiMethodId':'" + id + "'}",
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function (data) {
                var content = JSON.parse(data.d).Content[0];
                $("#contentContainer").setTemplateURL('Template/Content.html', null, { filter_data: false });
                $("#contentContainer").processTemplate(content);
            },
            error: function (e) {
            }
        });
    }
}
