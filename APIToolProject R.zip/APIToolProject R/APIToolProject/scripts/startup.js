﻿$(document).ready(function () {
    $.getJSON("JSON/Menu.json", function (data) {
        var menu = data.Menu;
        $('#menuId').tree({
            data: menu,
            autoOpen: true,
            dragAndDrop: true,
            selectable: true

        });
    });
    $.getJSON("JSON/FedEx.json", function (data) {
        var content = data.Content[0];
        debugger;
        $("#contentContainer").setTemplateURL('Template/Content.html', null, { filter_data: false });
        $("#contentContainer").processTemplate(content);
    });

});